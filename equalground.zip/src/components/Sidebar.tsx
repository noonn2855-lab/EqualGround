import React, { useState, useRef, useEffect } from 'react';
import {
  Home,
  MessageSquare,
  BookHeart,
  Megaphone,
  PhoneCall,
  Shield,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  X,
  BookOpen,
  Settings,
  LogIn,
  LogOut,
  Wifi,
  WifiOff
} from 'lucide-react';
import { ViewType, UserProfile } from '../types';

interface SidebarProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  user: UserProfile;
  isOnline: boolean;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onSignOut: () => void;
  onOpenLogin: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  user,
  isOnline,
  isOpenMobile,
  onCloseMobile,
  isCollapsed,
  onToggleCollapse,
  onSignOut,
  onOpenLogin
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const profileMenuRef = useRef<HTMLDivElement>(null);

  // Close profile dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        profileMenuRef.current &&
        !profileMenuRef.current.contains(event.target as Node)
      ) {
        setShowProfileMenu(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Close popover when collapsing/expanding
  useEffect(() => {
    setShowProfileMenu(false);
  }, [isCollapsed]);

  const navItems: { id: ViewType; label: string; icon: React.ReactNode; description: string }[] = [
    {
      id: 'home',
      label: 'Home',
      icon: <Home className="w-5 h-5 shrink-0" />,
      description: 'Feature discovery boxes'
    },
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <MessageSquare className="w-5 h-5 shrink-0" />,
      description: 'Social feed & community'
    },
    {
      id: 'journal',
      label: 'Private Journal',
      icon: <BookHeart className="w-5 h-5 shrink-0" />,
      description: 'Device-only safe vault'
    },
    {
      id: 'changelab',
      label: 'Change Lab',
      icon: <Megaphone className="w-5 h-5 shrink-0" />,
      description: 'Civic proposals & reform'
    },
    {
      id: 'emergency',
      label: 'Emergency Contacts',
      icon: <PhoneCall className="w-5 h-5 shrink-0" />,
      description: 'Location-based numbers'
    }
  ];

  const handleSelectView = (view: ViewType) => {
    onNavigate(view);
    onCloseMobile();
    setShowProfileMenu(false);
  };

  const renderProfileDropdownContent = () => (
    <div className="w-64 bg-slate-900 rounded-2xl shadow-2xl border border-slate-700/80 p-3 z-50 animate-in fade-in zoom-in-95 text-left text-slate-100">
      {/* User Info Header */}
      <div className="p-2 pb-2.5 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-xs">
            {user.avatarSeed}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-bold text-slate-100 truncate">
              {user.name}
            </p>
            <p className="text-[10px] text-slate-400 truncate">
              {user.isGuest ? 'Guest Session' : user.email || 'Registered Advocate'}
            </p>
          </div>
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-[10px] font-medium text-emerald-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span>Status: Authenticated Session</span>
        </div>
      </div>

      {/* Account Navigation Options */}
      <div className="py-2 space-y-1">
        <button
          onClick={() => handleSelectView('rules-guides')}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 text-xs font-semibold text-sky-400 hover:bg-slate-800 rounded-xl transition-colors text-left cursor-pointer"
        >
          <BookOpen className="w-4 h-4" />
          <span>Rules & Guides</span>
        </button>

        <button
          onClick={() => handleSelectView('emergency')}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 rounded-xl transition-colors text-left cursor-pointer"
        >
          <PhoneCall className="w-4 h-4 text-rose-400" />
          <span>Emergency Contacts</span>
        </button>

        <button
          onClick={() => handleSelectView('settings')}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 rounded-xl transition-colors text-left cursor-pointer"
        >
          <Settings className="w-4 h-4 text-slate-400" />
          <span>Profile & Privacy Settings</span>
        </button>

        <button
          onClick={() => handleSelectView('settings')}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 rounded-xl transition-colors text-left cursor-pointer"
        >
          <Shield className="w-4 h-4 text-slate-400" />
          <span>Data Storage & Security</span>
        </button>

        {user.isGuest && (
          <button
            onClick={() => {
              setShowProfileMenu(false);
              onOpenLogin();
              onCloseMobile();
            }}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 text-xs font-medium text-sky-400 hover:bg-slate-800 rounded-xl transition-colors text-left cursor-pointer"
          >
            <LogIn className="w-4 h-4" />
            <span>Upgrade to Permanent Account</span>
          </button>
        )}
      </div>

      {/* Logout Option */}
      <div className="pt-2 border-t border-slate-800">
        <button
          onClick={() => {
            setShowProfileMenu(false);
            onSignOut();
            onCloseMobile();
          }}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 text-xs font-semibold text-rose-400 hover:bg-rose-950/40 rounded-xl transition-colors text-left cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Log Out</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs md:hidden"
          aria-hidden="true"
        />
      )}

      {/* Main Left Sidebar with Distinctive Color & Picture */}
      <aside
        className={`fixed md:sticky top-0 left-0 z-40 h-screen bg-[#0c1427] text-slate-200 border-r border-slate-800/90 shadow-xl flex flex-col justify-between transition-all duration-200 ease-in-out md:translate-x-0 ${
          isOpenMobile ? 'translate-x-0 w-72' : '-translate-x-full'
        } ${isCollapsed ? 'md:w-20' : 'md:w-68'}`}
        aria-label="Navigation sidebar"
      >
        <div className="flex flex-col flex-1 min-h-0">
          {/* Brand Header & Collapse Toggle */}
          <div
            className={`p-3.5 border-b border-slate-800/80 flex items-center ${
              isCollapsed ? 'md:justify-center justify-between' : 'justify-between'
            }`}
          >
            {/* Expanded Brand Title / Logo */}
            {(!isCollapsed || isOpenMobile) && (
              <button
                onClick={() => handleSelectView('home')}
                className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none min-w-0"
                title="EqualGround Home"
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-900 via-sky-600 to-emerald-600 flex items-center justify-center text-white shadow-xs ring-1 ring-white/10 shrink-0">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
                    <path d="M12 3V21" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
                    <path d="M5 8H19" stroke="#E0F2FE" strokeWidth="2" strokeLinecap="round" />
                    <circle cx="5" cy="13" r="3" fill="#F87171" />
                    <circle cx="19" cy="13" r="3" fill="#34D399" />
                    <path d="M8 21H16" stroke="#38BDF8" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
                <div className="min-w-0">
                  <h1 className="text-sm font-bold tracking-tight text-white group-hover:text-sky-400 transition-colors truncate">
                    EqualGround
                  </h1>
                  <p className="text-[10px] text-slate-400 truncate">
                    Human Rights & Safety
                  </p>
                </div>
              </button>
            )}

            {/* Collapsed Brand Icon (desktop only) */}
            {isCollapsed && !isOpenMobile && (
              <button
                onClick={() => handleSelectView('home')}
                className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-900 via-sky-600 to-emerald-600 flex items-center justify-center text-white shadow-xs ring-1 ring-white/10 cursor-pointer shrink-0"
                title="EqualGround Home"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
                  <path d="M12 3V21" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
                  <path d="M5 8H19" stroke="#E0F2FE" strokeWidth="2" strokeLinecap="round" />
                  <circle cx="5" cy="13" r="3" fill="#F87171" />
                  <circle cx="19" cy="13" r="3" fill="#34D399" />
                  <path d="M8 21H16" stroke="#38BDF8" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </button>
            )}

            {/* Desktop Collapse/Expand Toggle Button */}
            <div className="hidden md:flex items-center">
              <button
                onClick={onToggleCollapse}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-lg transition-colors cursor-pointer"
                title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              >
                {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
              </button>
            </div>

            {/* Mobile Close Button */}
            <button
              onClick={onCloseMobile}
              className="md:hidden p-1.5 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-lg transition-colors cursor-pointer"
              title="Close sidebar"
              aria-label="Close sidebar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Sidebar Picture Banner (Shown when expanded) */}
          {(!isCollapsed || isOpenMobile) && (
            <div className="px-3 pt-3 pb-1">
              <div className="relative rounded-2xl overflow-hidden border border-slate-700/60 shadow-inner group">
                <div className="relative aspect-16/9 w-full bg-slate-800 overflow-hidden">
                  <img
                    src="/src/assets/images/sidebar_community_banner_1791864208709.jpg"
                    alt="Diverse community members standing together in solidarity in a sunlit architectural cloister"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0c1427] via-[#0c1427]/40 to-transparent pointer-events-none" />
                  <div className="absolute bottom-2 left-2.5 right-2.5 text-white pointer-events-none">
                    <p className="text-[11px] font-bold leading-tight drop-shadow-xs">Community Haven</p>
                    <p className="text-[10px] text-slate-300 leading-tight mt-0.5">Dignity, equality & mutual protection</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Links */}
          <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-1">
            {(!isCollapsed || isOpenMobile) && (
              <div className="px-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Navigation
              </div>
            )}

            {navItems.map((item) => {
              const isActive = currentView === item.id;
              const isItemCollapsed = isCollapsed && !isOpenMobile;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectView(item.id)}
                  title={isItemCollapsed ? `${item.label} — ${item.description}` : undefined}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs transition-all text-left group cursor-pointer ${
                    isItemCollapsed ? 'justify-center' : ''
                  } ${
                    isActive
                      ? 'bg-blue-600/25 text-sky-300 border border-blue-500/35 shadow-xs font-bold'
                      : 'text-slate-300 hover:bg-slate-800/70 hover:text-white font-medium'
                  }`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <span
                    className={`transition-colors shrink-0 ${
                      isActive
                        ? 'text-sky-400'
                        : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  >
                    {item.icon}
                  </span>
                  {(!isCollapsed || isOpenMobile) && (
                    <div className="flex-1 min-w-0">
                      <span className="block truncate text-slate-100 font-semibold">{item.label}</span>
                      <span className="block text-[10px] text-slate-400 truncate">
                        {item.description}
                      </span>
                    </div>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Area: Profile / Account (DE Badge) & Safe Session */}
        <div className="border-t border-slate-800/90 bg-[#080d1a]">
          {/* Profile / Account Control with 'DE' Avatar Badge */}
          <div className="p-2 relative" ref={profileMenuRef}>
            {(!isCollapsed || isOpenMobile) ? (
              <div>
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="w-full flex items-center gap-2.5 p-2 rounded-xl border border-slate-700/60 bg-slate-800/60 hover:bg-slate-800 hover:border-slate-600 transition-colors cursor-pointer text-left shadow-2xs"
                  aria-label="User account and profile menu"
                  aria-expanded={showProfileMenu}
                >
                  {/* Avatar badge (e.g. 'DE' or 'GA') */}
                  <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center shadow-xs shrink-0">
                    {user.avatarSeed}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-slate-100 truncate">
                      {user.name}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate">
                      {user.isGuest ? 'Guest Session' : user.email || 'Registered Advocate'}
                    </p>
                  </div>
                  <ChevronUp
                    className={`w-3.5 h-3.5 text-slate-400 transition-transform ${
                      showProfileMenu ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {/* Popover upward when expanded */}
                {showProfileMenu && (
                  <div className="absolute left-2 right-2 bottom-full mb-2">
                    {renderProfileDropdownContent()}
                  </div>
                )}
              </div>
            ) : (
              /* Collapsed avatar button (desktop icon view) */
              <div className="flex justify-center">
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="w-10 h-10 rounded-xl bg-blue-600 text-white font-bold text-xs flex items-center justify-center shadow-xs cursor-pointer hover:ring-2 hover:ring-sky-400/50 transition-all"
                  title={`Profile: ${user.name} (${user.avatarSeed})`}
                  aria-label="User account menu"
                  aria-expanded={showProfileMenu}
                >
                  {user.avatarSeed}
                </button>

                {/* Popover opens to the right when collapsed */}
                {showProfileMenu && (
                  <div className="absolute left-full ml-3 bottom-0">
                    {renderProfileDropdownContent()}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Network Status indicator */}
          {(!isCollapsed || isOpenMobile) && (
            <div className="px-3 pb-2 pt-0.5 flex items-center justify-between text-[10px] text-slate-400">
              <span className="flex items-center gap-1">
                {isOnline ? (
                  <>
                    <Wifi className="w-3 h-3 text-emerald-400" />
                    <span>Protected & Online</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-3 h-3 text-amber-400" />
                    <span>Offline Cache Ready</span>
                  </>
                )}
              </span>
              <span>v1.2</span>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
