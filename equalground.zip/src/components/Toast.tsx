import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning';
  title: string;
  description?: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const Toast: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        const icons = {
          success: <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />,
          info: <Info className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />,
          warning: <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        };

        return (
          <div
            key={toast.id}
            className="pointer-events-auto p-3.5 bg-white border border-slate-200/90 rounded-xl shadow-lg flex items-start justify-between gap-3 animate-in slide-in-from-bottom-2 duration-150"
            role="status"
            aria-live="polite"
          >
            <div className="flex items-start gap-2.5">
              {icons[toast.type]}
              <div>
                <p className="text-xs font-bold text-slate-900">{toast.title}</p>
                {toast.description && (
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                    {toast.description}
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={() => onDismiss(toast.id)}
              className="p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
              aria-label="Dismiss toast"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
