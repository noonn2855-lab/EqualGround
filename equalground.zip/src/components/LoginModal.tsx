import React, { useState } from 'react';
import { Eye, EyeOff, ShieldCheck, UserCheck, ArrowRight, X, AlertCircle } from 'lucide-react';
import { UserProfile } from '../types';

interface LoginModalProps {
  isOpen: boolean;
  initialTab?: 'signin' | 'register';
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  initialTab = 'signin',
  onClose,
  onSuccess
}) => {
  const [tab, setTab] = useState<'signin' | 'register'>(initialTab);
  const [email, setEmail] = useState('demo.advocate@equalground.org');
  const [password, setPassword] = useState('EqualRights2026!');
  const [name, setName] = useState('JusticeAdvocate');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);

  React.useEffect(() => {
    if (isOpen) {
      setTab(initialTab);
      setErrorMessage(null);
      setInfoMessage(null);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email || !email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }

    if (tab === 'register' && !name.trim()) {
      setErrorMessage('Please provide a display name or pseudonym.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const user: UserProfile = {
        id: `user-${Date.now()}`,
        name: tab === 'register' ? name.trim() : (email.split('@')[0] || 'Advocate'),
        email: email,
        isGuest: false,
        avatarSeed: (tab === 'register' ? name : email).slice(0, 2).toUpperCase(),
        joinedDate: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
      };
      onSuccess(user);
      onClose();
    }, 450);
  };

  const handleGuestContinue = () => {
    const guestUser: UserProfile = {
      id: `guest-${Date.now()}`,
      name: 'Guest Advocate',
      isGuest: true,
      avatarSeed: 'GA',
      joinedDate: 'Active Session'
    };
    onSuccess(guestUser);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-labelledby="login-title"
    >
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Top close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand header */}
        <div className="pt-8 pb-4 px-8 text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-50 border border-blue-100 mb-4 shadow-2xs">
            <svg className="w-8 h-8" viewBox="0 0 40 40" fill="none">
              <path d="M20 5V35" stroke="#1E3A8A" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M8 14H32" stroke="#0284C7" strokeWidth="2.5" strokeLinecap="round" />
              <circle cx="8" cy="22" r="5" fill="#EF4444" fillOpacity="0.85" />
              <circle cx="32" cy="22" r="5" fill="#10B981" fillOpacity="0.85" />
              <path d="M14 35H26" stroke="#38BDF8" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </div>
          <h2 id="login-title" className="text-2xl font-bold text-slate-900 tracking-tight">
            EqualGround
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            A safe space for dignity, justice, and human rights.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-200 px-8">
          <button
            type="button"
            onClick={() => { setTab('signin'); setErrorMessage(null); setInfoMessage(null); }}
            className={`flex-1 pb-3 text-sm font-semibold transition-colors border-b-2 cursor-pointer ${
              tab === 'signin'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            Sign in
          </button>
          <button
            type="button"
            onClick={() => { setTab('register'); setErrorMessage(null); setInfoMessage(null); }}
            className={`flex-1 pb-3 text-sm font-semibold transition-colors border-b-2 cursor-pointer ${
              tab === 'register'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            Create account
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-8 pt-6 space-y-4">
          {errorMessage && (
            <div className="flex items-start gap-2.5 p-3 text-xs text-rose-700 bg-rose-50 rounded-xl border border-rose-200">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {infoMessage && (
            <div className="flex items-start gap-2.5 p-3 text-xs text-blue-800 bg-blue-50 rounded-xl border border-blue-200">
              <span>{infoMessage}</span>
            </div>
          )}

          {tab === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Pseudonym or Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. HopefulVoice or Alex"
                className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition-all"
              />
              <p className="mt-1 text-[11px] text-slate-400">Feel free to use an anonymous alias for privacy.</p>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Email address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.org"
              required
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition-all"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Password
              </label>
              {tab === 'signin' && (
                <button
                  type="button"
                  onClick={() => setInfoMessage('Demo mode: you can enter any password (min 6 characters) to access.')}
                  className="text-[11px] text-blue-600 hover:underline cursor-pointer"
                >
                  Demo password hint
                </button>
              )}
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-3.5 py-2.5 pr-10 text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm shadow-xs transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
          >
            {isLoading ? (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{tab === 'signin' ? 'Sign in to EqualGround' : 'Create safe account'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-3 text-slate-400">or</span>
            </div>
          </div>

          {/* Continue as Guest Button */}
          <button
            type="button"
            onClick={handleGuestContinue}
            className="w-full py-2.5 px-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>Continue as Guest</span>
          </button>

          {/* Disclaimers & Ethics */}
          <div className="pt-2 text-[11px] leading-relaxed text-slate-400 text-center">
            <p className="flex items-center justify-center gap-1.5 font-medium text-slate-500">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>Transparent Security Disclosure</span>
            </p>
            <p className="mt-0.5">
              This platform runs client-side. No passwords or identifiable data are transmitted to external surveillance databases.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
