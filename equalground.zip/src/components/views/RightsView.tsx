import React, { useState } from 'react';
import {
  Scale,
  Shield,
  PhoneCall,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Search,
  BookOpen,
  Copy,
  Check
} from 'lucide-react';
import { RightsGuide } from '../../types';

interface RightsViewProps {
  guides: RightsGuide[];
  searchQuery: string;
  onShowToast: (title: string, desc?: string, type?: 'success' | 'info') => void;
}

export const RightsView: React.FC<RightsViewProps> = ({
  guides,
  searchQuery,
  onShowToast
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedGuideId, setExpandedGuideId] = useState<string | null>(guides[0]?.id || null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'All Guides' },
    { id: 'violence', label: 'Sexual Violence & Consent' },
    { id: 'racial', label: 'Racial & Cultural Bias' },
    { id: 'gender', label: 'Gender Equality' },
    { id: 'tradition', label: 'Traditions & Bodily Autonomy' },
    { id: 'labor', label: 'Labor & Workplace' }
  ];

  const filteredGuides = guides.filter((g) => {
    const matchesCategory = selectedCategory === 'all' || g.category === selectedCategory;
    const matchesSearch =
      !searchQuery ||
      g.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.legalBasis.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleExpand = (id: string) => {
    setExpandedGuideId(expandedGuideId === id ? null : id);
  };

  const copyActionPlan = (guide: RightsGuide) => {
    const planText = `[EQUALGROUND ACTION PLAN: ${guide.title}]\n\nSummary:\n${guide.summary}\n\nKey Legal Protections:\n${guide.legalBasis}\n\nImmediate Action Steps:\n${guide.actionSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}\n\nVerified Helplines:\n${guide.resources.map(r => `${r.name}: ${r.contact}`).join('\n')}`;

    navigator.clipboard.writeText(planText).then(() => {
      setCopiedId(guide.id);
      onShowToast('Action Plan Copied', 'Plain text copied safely to your clipboard.', 'success');
      setTimeout(() => setCopiedId(null), 2500);
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header and overview */}
      <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-sky-400 uppercase tracking-wider">
            <Scale className="w-4 h-4" />
            <span>Universal Human Rights Repository</span>
          </div>
          <h2 className="mt-1 text-xl sm:text-2xl font-bold text-neutral-900 dark:text-neutral-100">
            Know Your Inherent Rights
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 max-w-2xl leading-relaxed">
            International law, civil statutes, and human dignity establish clear protections. Explore actionable, step-by-step guidance on responding to violence, discrimination, and coerced customs.
          </p>
        </div>

        <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-600 dark:text-neutral-300 shrink-0">
          <p className="font-semibold text-neutral-900 dark:text-white flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-emerald-500" />
            <span>Offline Ready</span>
          </p>
          <p className="text-[11px] text-neutral-400 mt-0.5">All guides cached for offline emergency use.</p>
        </div>
      </div>

      {/* Interactive Category Segmented Tabs */}
      <div className="flex items-center gap-1.5 p-1.5 bg-neutral-100 dark:bg-neutral-800/80 rounded-2xl overflow-x-auto scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Guides List */}
      {filteredGuides.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
          <BookOpen className="w-10 h-10 text-neutral-400 mx-auto mb-3 opacity-60" />
          <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200">No matching guides found</h3>
          <p className="text-xs text-neutral-400 mt-1">Try clearing your search query or selecting "All Guides".</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredGuides.map((guide) => {
            const isExpanded = expandedGuideId === guide.id;

            // Accent theme based on guide
            const accentClasses = {
              red: 'border-l-4 border-l-rose-500',
              blue: 'border-l-4 border-l-blue-600',
              sky: 'border-l-4 border-l-sky-500',
              emerald: 'border-l-4 border-l-emerald-500'
            }[guide.accentColor];

            return (
              <div
                key={guide.id}
                className={`rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-xs transition-all overflow-hidden ${accentClasses}`}
              >
                {/* Header click row */}
                <div
                  onClick={() => toggleExpand(guide.id)}
                  className="p-5 sm:p-6 cursor-pointer flex items-start justify-between gap-4 select-none hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    {/* Unboxed clean metadata with typography separator */}
                    <div className="text-[11px] font-medium text-neutral-500 dark:text-neutral-400 flex items-center gap-2">
                      <span className="uppercase tracking-wider font-bold text-neutral-700 dark:text-neutral-300">
                        {guide.category} Protection
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Verified Standard</span>
                    </div>

                    <h3 className="mt-1 text-base sm:text-lg font-bold text-neutral-900 dark:text-neutral-100">
                      {guide.title}
                    </h3>
                    <p className="mt-1.5 text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                      {guide.summary}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 pt-1">
                    <button
                      type="button"
                      className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg"
                      aria-label={isExpanded ? 'Collapse guide' : 'Expand guide'}
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5" />
                      ) : (
                        <ChevronDown className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Expanded Detailed Guidance */}
                {isExpanded && (
                  <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-neutral-100 dark:border-neutral-800/80 space-y-6">
                    {/* Legal Framework & Authority */}
                    <div className="p-3.5 rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40 text-xs">
                      <p className="font-semibold text-blue-950 dark:text-sky-300 flex items-center gap-1.5">
                        <Scale className="w-3.5 h-3.5 text-blue-600 dark:text-sky-400" />
                        <span>Binding Legal Protections</span>
                      </p>
                      <p className="mt-1 text-blue-900/80 dark:text-sky-200/80 leading-relaxed">
                        {guide.legalBasis}
                      </p>
                    </div>

                    {/* Detailed Principles */}
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2.5">
                        Key Rights & Autonomy Principles
                      </h4>
                      <ul className="space-y-2">
                        {guide.fullContent.map((point, index) => (
                          <li
                            key={index}
                            className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0 mt-2" />
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Actionable Steps */}
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2.5">
                        Recommended Action Steps
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {guide.actionSteps.map((step, idx) => (
                          <div
                            key={idx}
                            className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200/70 dark:border-neutral-800 flex items-start gap-2.5 text-xs text-neutral-800 dark:text-neutral-200"
                          >
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                            <span>{step}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Verified Organizations & Hotlines */}
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2.5">
                        Verified Contacts & Emergency Helplines
                      </h4>
                      <div className="space-y-2">
                        {guide.resources.map((res, i) => (
                          <div
                            key={i}
                            className="p-3 rounded-xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-3 text-xs"
                          >
                            <div>
                              <p className="font-semibold text-neutral-900 dark:text-neutral-100 flex items-center gap-1.5">
                                {res.isHotline && (
                                  <PhoneCall className="w-3.5 h-3.5 text-rose-500" />
                                )}
                                <span>{res.name}</span>
                              </p>
                              <p className="text-neutral-500 dark:text-neutral-400 font-mono mt-0.5">
                                {res.contact}
                              </p>
                            </div>
                            <span className="text-[10px] text-neutral-400">Verified</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Footer Copy / Save button */}
                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={() => copyActionPlan(guide)}
                        className="px-3.5 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
                      >
                        {copiedId === guide.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                            <span>Plan Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Action Plan</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
