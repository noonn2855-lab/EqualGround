import React, { useState } from 'react';
import {
  Lock,
  Plus,
  Trash2,
  Edit3,
  Download,
  AlertTriangle,
  Search,
  Check,
  Tag,
  Shield,
  FileText
} from 'lucide-react';
import { JournalEntry } from '../../types';

interface JournalViewProps {
  entries: JournalEntry[];
  onSaveEntry: (entry: JournalEntry) => void;
  onDeleteEntry: (id: string) => void;
  onClearAll: () => void;
  onShowToast: (title: string, desc?: string, type?: 'success' | 'info' | 'warning') => void;
}

export const JournalView: React.FC<JournalViewProps> = ({
  entries,
  onSaveEntry,
  onDeleteEntry,
  onClearAll,
  onShowToast
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [activeEntryId, setActiveEntryId] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Form states
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<JournalEntry['category']>('Reflection');
  const [content, setContent] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const categories: ('All' | JournalEntry['category'])[] = [
    'All',
    'Reflection',
    'Incident Log',
    'Legal Note',
    'Hope & Healing'
  ];

  const handleOpenNew = () => {
    setActiveEntryId(null);
    setTitle('');
    setCategory('Reflection');
    setContent('');
    setTags([]);
    setTagInput('');
    setIsEditing(true);
  };

  const handleOpenEdit = (entry: JournalEntry) => {
    setActiveEntryId(entry.id);
    setTitle(entry.title);
    setCategory(entry.category);
    setContent(entry.content);
    setTags(entry.tags || []);
    setTagInput('');
    setIsEditing(true);
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const clean = tagInput.trim().replace(/^#/, '');
      if (clean && !tags.includes(clean)) {
        setTags([...tags, clean]);
        setTagInput('');
      }
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      onShowToast('Missing Content', 'Please provide a title and note body.', 'warning');
      return;
    }

    const newEntry: JournalEntry = {
      id: activeEntryId || `journal-${Date.now()}`,
      title: title.trim(),
      category: category,
      date: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      }),
      content: content.trim(),
      isConfidential: true,
      tags: tags
    };

    onSaveEntry(newEntry);
    setIsEditing(false);
    onShowToast(
      activeEntryId ? 'Note Updated' : 'Private Note Saved',
      'Saved directly to device storage.',
      'success'
    );
  };

  const handleExport = () => {
    if (entries.length === 0) {
      onShowToast('No Entries', 'Your journal is currently empty.', 'info');
      return;
    }

    const payload = entries.map((e) => ({
      title: e.title,
      category: e.category,
      date: e.date,
      tags: e.tags,
      content: e.content
    }));

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `EqualGround-PrivateNotes-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onShowToast('Notes Exported', 'Your local notes have been downloaded as a JSON file.', 'success');
  };

  const filteredEntries = entries.filter((e) => {
    const matchesCat = filterCategory === 'All' || e.category === filterCategory;
    const matchesSearch =
      !searchQuery ||
      e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner and Vault Overview with Serene Journal Photography */}
      <div className="overflow-hidden rounded-3xl bg-white border border-slate-200/90 shadow-sm grid grid-cols-1 md:grid-cols-12 items-stretch">
        <div className="md:col-span-7 p-6 sm:p-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-sky-700 uppercase tracking-wider">
              <Lock className="w-4 h-4" />
              <span>Private Local Safe Vault</span>
            </div>
            <h1 className="mt-1 text-xl sm:text-2xl font-bold text-slate-900">
              Private Journal & Incident Log
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-600 leading-relaxed">
              Record sensitive experiences, dates, thoughts, or legal notes in calm confidence. All entries are saved locally on this browser only—never sent to cloud servers.
            </p>
          </div>

          <div className="mt-5 flex items-center gap-2.5 shrink-0 flex-wrap">
            <button
              onClick={handleExport}
              className="px-3.5 py-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Notes</span>
            </button>
            <button
              onClick={handleOpenNew}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Entry</span>
            </button>
          </div>
        </div>

        {/* Serene Journal Still Life Image */}
        <div className="md:col-span-5 relative min-h-[180px] md:min-h-full bg-slate-100 overflow-hidden border-t md:border-t-0 md:border-l border-slate-200/80">
          <img
            src="/src/assets/images/privacy_journal_vault_1791702642961.jpg"
            alt="Calm still life of an open personal journal with a classic fountain pen on an oak desk in warm morning light"
            className="w-full h-full object-cover object-center"
            loading="eager"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-2.5 left-3 right-3 text-white text-[11px] font-medium leading-tight drop-shadow-xs">
            Safe, confidential reflection and local device storage
          </div>
        </div>
      </div>

      {/* Disclaimers & Safety Notice Banner */}
      <div className="p-4 rounded-xl bg-sky-50 border border-sky-100 flex items-start justify-between gap-3 text-xs text-sky-900 shadow-2xs">
        <div className="flex items-start gap-2.5">
          <Shield className="w-4 h-4 text-sky-700 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-sky-950">Client-Side Privacy Notice</p>
            <p className="text-[11px] text-sky-800 mt-0.5 leading-relaxed">
              Data is saved strictly to your device’s local browser memory. No server database is queried. If someone else shares this physical device, use the Quick Wipe button below or browse in private mode.
            </p>
          </div>
        </div>
        {entries.length > 0 && (
          <button
            onClick={() => setShowClearConfirm(true)}
            className="text-[11px] font-semibold text-rose-600 hover:underline shrink-0 cursor-pointer"
          >
            Quick Wipe
          </button>
        )}
      </div>

      {/* Write/Edit Modal Dialog */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-xl bg-white rounded-2xl p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-sky-700" />
                <h3 className="text-base font-bold text-slate-900">
                  {activeEntryId ? 'Edit Private Note' : 'Create New Private Note'}
                </h3>
              </div>
              <button
                onClick={() => setIsEditing(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Incident on October 8th, or Reflection on Self-Dignity"
                  required
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as JournalEntry['category'])}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                  >
                    <option value="Reflection">Reflection</option>
                    <option value="Incident Log">Incident Log</option>
                    <option value="Legal Note">Legal Note</option>
                    <option value="Hope & Healing">Hope & Healing</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Add Tags
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyDown={handleAddTag}
                      placeholder="e.g. workplace (Enter)"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                    />
                  </div>
                </div>
              </div>

              {tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {tags.map((t) => (
                    <span
                      key={t}
                      className="text-xs px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 flex items-center gap-1"
                    >
                      <span>#{t}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveTag(t)}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Content (Private to your browser)
                </label>
                <textarea
                  rows={6}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Record full details, thoughts, timeline, or steps taken..."
                  required
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30 resize-none leading-relaxed"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold cursor-pointer shadow-xs"
                >
                  Save Note Locally
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Clear All Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl p-6 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Wipe Private Notes?
            </h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              This will irreversibly delete all {entries.length} notes from this browser. Consider clicking "Export Notes" first if you need a personal backup.
            </p>
            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2 text-xs font-semibold rounded-xl bg-slate-100 text-slate-700 cursor-pointer hover:bg-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onClearAll();
                  setShowClearConfirm(false);
                  onShowToast('Vault Cleared', 'All notes removed from this device.', 'info');
                }}
                className="flex-1 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-700 text-white cursor-pointer"
              >
                Confirm Wipe
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                filterCategory === cat
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search your notes..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          />
        </div>
      </div>

      {/* Entries List or Empty State */}
      {filteredEntries.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
          <Lock className="w-10 h-10 text-slate-400 mx-auto mb-3 opacity-60" />
          <h3 className="text-sm font-bold text-slate-800">
            Your Private Vault is Quiet
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            No notes found matching your criteria. Start writing freely knowing your thoughts remain yours alone.
          </p>
          <button
            onClick={handleOpenNew}
            className="mt-4 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Write First Note</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredEntries.map((entry) => (
            <div
              key={entry.id}
              className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col justify-between hover:border-slate-300 transition-all"
            >
              <div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 pb-2 border-b border-slate-100">
                  {/* Clean unboxed metadata with typography separator */}
                  <div className="flex items-center gap-1.5 font-medium">
                    <span className="text-slate-800 font-semibold">{entry.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{entry.date}</span>
                  </div>
                  <span className="flex items-center gap-1 text-emerald-700 font-medium">
                    <Shield className="w-3 h-3" /> Stored locally
                  </span>
                </div>

                <h3 className="mt-2.5 text-base font-bold text-slate-900">
                  {entry.title}
                </h3>

                <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line line-clamp-5">
                  {entry.content}
                </p>

                {entry.tags && entry.tags.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {entry.tags.map((t) => (
                      <span
                        key={t}
                        className="text-[10px] text-slate-500"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  onClick={() => handleOpenEdit(entry)}
                  className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  aria-label="Edit note"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => onDeleteEntry(entry.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  aria-label="Delete note"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
