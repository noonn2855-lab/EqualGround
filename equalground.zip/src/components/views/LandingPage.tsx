import React from 'react';
import { ShieldCheck, ArrowRight, UserCheck, Scale, Lock, Users } from 'lucide-react';

interface LandingPageProps {
  onOpenLogin: () => void;
  onOpenSignUp: () => void;
  onContinueAsGuest: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onOpenLogin,
  onOpenSignUp,
  onContinueAsGuest
}) => {
  return (
    <div className="min-h-screen flex flex-col justify-between py-8 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto animate-in fade-in duration-300">
      {/* Brand Header */}
      <header className="flex items-center justify-between pb-6 border-b border-slate-200/90">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-900 via-sky-600 to-emerald-600 flex items-center justify-center text-white shadow-xs ring-1 ring-black/5">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
              <path d="M12 3V21" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
              <path d="M5 8H19" stroke="#E0F2FE" strokeWidth="2" strokeLinecap="round" />
              <circle cx="5" cy="13" r="3" fill="#F87171" />
              <circle cx="19" cy="13" r="3" fill="#34D399" />
              <path d="M8 21H16" stroke="#38BDF8" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900">
              EqualGround
            </h1>
            <p className="text-xs text-slate-500">
              Human Rights, Safe Voices & Dignity
            </p>
          </div>
        </div>

        {/* Top Actions: Log In / Sign Up */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onOpenLogin}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Log In
          </button>
          <button
            onClick={onOpenSignUp}
            className="px-4 py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white shadow-xs transition-colors cursor-pointer"
          >
            Sign Up
          </button>
        </div>
      </header>

      {/* Main Hero & Welcome */}
      <main className="my-auto py-10 sm:py-14 text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-xs font-medium mb-5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>A Safe, Dignified Harbor for Everyone</span>
        </div>

        <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 leading-tight">
          Every Voice Deserves Safety.{' '}
          <span className="text-blue-700 block mt-1">
            Every Person Deserves Equality.
          </span>
        </h2>

        <p className="mt-4 text-sm sm:text-base text-slate-600 leading-relaxed font-normal max-w-2xl mx-auto">
          EqualGround provides plain-language human rights guides, client-side private journaling, anonymous community dialogue, and civic reform tools—without judgment, corporate tracking, or exposure.
        </p>

        {/* Primary CTA Buttons */}
        <div className="mt-7 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={onOpenLogin}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-sm shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Log In to Account</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSignUp}
            className="w-full sm:w-auto px-6 py-3 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Create New Account</span>
          </button>
        </div>

        <div className="mt-3.5">
          <button
            onClick={onContinueAsGuest}
            className="text-xs text-slate-500 hover:text-slate-900 inline-flex items-center gap-1.5 transition-colors cursor-pointer underline-offset-4 hover:underline"
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Or continue as guest without sign-up</span>
          </button>
        </div>

        {/* Natural Community Photographic Showcase */}
        <div className="mt-10 rounded-2xl overflow-hidden border border-slate-200/90 shadow-sm bg-white text-left">
          <div className="relative aspect-16/9 sm:aspect-21/9 max-h-72 overflow-hidden bg-slate-100">
            <img
              src="/src/assets/images/home_community_hero_1791702610169.jpg"
              alt="A welcoming, diverse community gathered together in a sunlit courtyard for open dialogue and mutual support"
              className="w-full h-full object-cover object-center"
              loading="eager"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
            <div className="absolute bottom-3 left-4 right-4 text-white text-xs">
              <span className="font-semibold">Inclusive Community Harbor</span>
              <span className="mx-1.5 opacity-60">·</span>
              <span className="opacity-90">Open dialogue, equality, and mutual protection</span>
            </div>
          </div>
        </div>

        {/* 3 Value Pillars */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
          <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center mb-2.5">
              <Scale className="w-4 h-4" />
            </div>
            <h3 className="text-xs font-bold text-slate-900">Inherent Rights</h3>
            <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
              Actionable legal guides against discrimination, harassment, and coercive traditions.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
            <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center mb-2.5">
              <Lock className="w-4 h-4" />
            </div>
            <h3 className="text-xs font-bold text-slate-900">Private Safe Vault</h3>
            <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
              Confidential notes and incident logs stored 100% locally in your browser.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center mb-2.5">
              <Users className="w-4 h-4" />
            </div>
            <h3 className="text-xs font-bold text-slate-900">Community & Action</h3>
            <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
              Anonymous solidarity feed and civic advocacy campaigns for lasting change.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="pt-6 border-t border-slate-200/90 text-center text-xs text-slate-500">
        <p>EqualGround · Dedicated to human dignity, safety, and universal rights.</p>
      </footer>
    </div>
  );
};
