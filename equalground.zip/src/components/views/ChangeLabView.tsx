import React, { useState } from 'react';
import {
  Megaphone,
  CheckCircle,
  ThumbsUp,
  Plus,
  Sparkles,
  Search,
  Scale,
  Users
} from 'lucide-react';
import { ChangeProposal, UserProfile } from '../../types';

interface ChangeLabViewProps {
  proposals: ChangeProposal[];
  user: UserProfile;
  onAddProposal: (proposal: ChangeProposal) => void;
  onToggleEndorse: (id: string) => void;
  onShowToast: (title: string, desc?: string, type?: 'success' | 'info') => void;
}

export const ChangeLabView: React.FC<ChangeLabViewProps> = ({
  proposals,
  user,
  onAddProposal,
  onToggleEndorse,
  onShowToast
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Proposal modal fields
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Institutional Reform');
  const [targetAudience, setTargetAudience] = useState('National Human Rights Commission');
  const [summary, setSummary] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !summary.trim()) {
      onShowToast('Missing Fields', 'Please complete the title and reform summary.', 'info');
      return;
    }

    const newProp: ChangeProposal = {
      id: `prop-${Date.now()}`,
      title: title.trim(),
      summary: summary.trim(),
      category: category,
      author: user.name,
      endorsements: 1,
      hasEndorsed: true,
      status: 'Proposed',
      targetAudience: targetAudience.trim(),
      date: 'Just now'
    };

    onAddProposal(newProp);
    setIsModalOpen(false);
    onShowToast('Civic Proposal Created', 'Your proposal is live for community endorsements.', 'success');
  };

  const filteredProposals = proposals.filter((p) => {
    return (
      !searchQuery ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner with Civic Volunteers Photographic Banner */}
      <div className="overflow-hidden rounded-3xl bg-white border border-slate-200/90 shadow-sm grid grid-cols-1 md:grid-cols-12 items-stretch">
        <div className="md:col-span-7 p-6 sm:p-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-blue-700 uppercase tracking-wider">
              <Megaphone className="w-4 h-4" />
              <span>Civic Action & Policy Innovation</span>
            </div>
            <h1 className="mt-1 text-xl sm:text-2xl font-bold text-slate-900">
              Change Lab
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-600 leading-relaxed">
              From lived struggle to systemic change. Endorse active campaigns or initiate reform proposals targeting harmful customs, workplace discrimination, and legal aid access.
            </p>
          </div>

          <div className="mt-5 flex items-center gap-3">
            <button
              onClick={() => {
                setTitle('');
                setSummary('');
                setCategory('Institutional Reform');
                setTargetAudience('National Human Rights Commission');
                setIsModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Propose Reform</span>
            </button>
            <span className="text-xs text-slate-500">
              Community-driven policy advocacy
            </span>
          </div>
        </div>

        {/* Civic Reform Photographic Showcase */}
        <div className="md:col-span-5 relative min-h-[180px] md:min-h-full bg-slate-100 overflow-hidden border-t md:border-t-0 md:border-l border-slate-200/80">
          <img
            src="/src/assets/images/civic_reform_changelab_1791702665381.jpg"
            alt="Civic volunteers and advocates collaborating around community initiatives and reform blueprints"
            className="w-full h-full object-cover object-center"
            loading="eager"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-2.5 left-3 right-3 text-white text-[11px] font-medium leading-tight drop-shadow-xs">
            Grassroots collaboration and democratic policy proposals
          </div>
        </div>
      </div>

      {/* Impact Stats Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Active Campaigns</p>
          <p className="mt-1 text-2xl font-black text-slate-900">
            {proposals.filter((p) => p.status === 'Active Campaign').length}
          </p>
          <p className="mt-1 text-[11px] text-slate-500">Mobilizing civic groups</p>
        </div>
        <div className="p-4 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Total Endorsements</p>
          <p className="mt-1 text-2xl font-black text-blue-700">
            {proposals.reduce((sum, p) => sum + p.endorsements, 0)}
          </p>
          <p className="mt-1 text-[11px] text-slate-500">Collective community votes</p>
        </div>
        <div className="p-4 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Under Formal Review</p>
          <p className="mt-1 text-2xl font-black text-emerald-700">
            {proposals.filter((p) => p.status === 'Under Review').length}
          </p>
          <p className="mt-1 text-[11px] text-slate-500">Transmitted to advisory boards</p>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative max-w-sm">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Filter proposals by title or policy..."
          className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
        />
      </div>

      {/* Proposals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredProposals.map((item) => {
          return (
            <div
              key={item.id}
              className="p-5 sm:p-6 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col justify-between hover:border-slate-300 transition-all"
            >
              <div>
                {/* Clean unboxed metadata with typography separator */}
                <div className="flex items-center justify-between text-[11px] text-slate-500 pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-1.5 font-medium">
                    <span className="text-slate-800 font-semibold">{item.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{item.date}</span>
                  </div>
                  <span className="font-semibold text-emerald-700">
                    {item.status}
                  </span>
                </div>

                <h3 className="mt-3 text-base font-bold text-slate-900 leading-snug">
                  {item.title}
                </h3>

                <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {item.summary}
                </p>

                <div className="mt-3.5 p-2.5 rounded-xl bg-slate-50 text-[11px] text-slate-600">
                  <span className="font-semibold text-slate-800">Target Authority:</span>{' '}
                  {item.targetAudience}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="text-xs text-slate-600 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" />
                  <span className="font-bold text-slate-900">{item.endorsements}</span>{' '}
                  <span>endorsements</span>
                </div>

                <button
                  onClick={() => onToggleEndorse(item.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    item.hasEndorsed
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                  }`}
                >
                  <ThumbsUp className={`w-3.5 h-3.5 ${item.hasEndorsed ? 'fill-emerald-600' : ''}`} />
                  <span>{item.hasEndorsed ? 'Endorsed' : 'Endorse'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal Dialog */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-2xl p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                Submit Civic Reform Proposal
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Proposal Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Free Emergency Legal Vouchers for Domestic Coercion Victims"
                  required
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Reform Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                  >
                    <option value="Institutional Reform">Institutional Reform</option>
                    <option value="Human Rights Statute">Human Rights Statute</option>
                    <option value="Access to Justice">Access to Justice</option>
                    <option value="Workplace Equality">Workplace Equality</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Target Authority
                  </label>
                  <input
                    type="text"
                    value={targetAudience}
                    onChange={(e) => setTargetAudience(e.target.value)}
                    placeholder="e.g. Ministry of Labor or UN Commission"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Proposed Solution & Expected Impact
                </label>
                <textarea
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  rows={4}
                  placeholder="Detail the specific policy amendment, oversight mechanism, or protections needed..."
                  required
                  className="w-full p-3 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30 resize-y leading-relaxed"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-xs cursor-pointer"
                >
                  Publish Proposal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
