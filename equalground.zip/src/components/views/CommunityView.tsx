import React, { useState } from 'react';
import {
  MessageSquare,
  Heart,
  Flag,
  Send,
  Search,
  Eye,
  Plus,
  User,
  UserX,
  Check
} from 'lucide-react';
import { CommunityPost, UserProfile, ViewType } from '../../types';

interface CommunityViewProps {
  posts: CommunityPost[];
  user: UserProfile;
  onAddPost: (post: CommunityPost) => void;
  onToggleSupport: (postId: string) => void;
  onAddComment: (postId: string, commentText: string, author: string) => void;
  onShowToast: (title: string, desc?: string, type?: 'success' | 'info' | 'warning') => void;
  onNavigate?: (view: ViewType) => void;
}

export const CommunityView: React.FC<CommunityViewProps> = ({
  posts,
  user,
  onAddPost,
  onToggleSupport,
  onAddComment,
  onShowToast
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCommentsPostId, setExpandedCommentsPostId] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});
  const [revealedWarnings, setRevealedWarnings] = useState<{ [postId: string]: boolean }>({});
  const [reportModalPostId, setReportModalPostId] = useState<string | null>(null);

  // New post inline creator
  const [isComposerOpen, setIsComposerOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<CommunityPost['category']>('Shared Story');
  const [isAnonymousMode, setIsAnonymousMode] = useState(false);
  const [hasTriggerWarning, setHasTriggerWarning] = useState(false);

  const filterOptions = ['All', 'Shared Story', 'Legal Question', 'Reform Idea', 'Solidarity'];

  const handleSubmitPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) {
      onShowToast('Missing Fields', 'Please enter a title and content for your post.', 'warning');
      return;
    }

    const post: CommunityPost = {
      id: `post-${Date.now()}`,
      title: newTitle.trim(),
      author: isAnonymousMode ? 'Anonymous Member' : user.name,
      isAnonymous: isAnonymousMode,
      category: newCategory,
      date: 'Just now',
      content: newContent.trim(),
      hasTriggerWarning: hasTriggerWarning,
      supportCount: 1,
      hasSupported: true,
      comments: []
    };

    onAddPost(post);
    setNewTitle('');
    setNewContent('');
    setIsComposerOpen(false);
    onShowToast(
      isAnonymousMode ? 'Posted Anonymously' : 'Published to Feed',
      isAnonymousMode
        ? 'Your post is live as "Anonymous Member" without your profile details.'
        : 'Your post is live with your profile.',
      'success'
    );
  };

  const handleSendComment = (postId: string) => {
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    // Use current user's pseudonym or guest name
    onAddComment(postId, text, user.name);
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
    onShowToast('Reply Posted', 'Thank you for supporting this peer.', 'success');
  };

  const handleReportPost = (postId: string) => {
    setReportModalPostId(null);
    onShowToast('Report Submitted', 'Moderators will review this entry for community safety.', 'info');
  };

  const filteredPosts = posts.filter((p) => {
    const matchesFilter = selectedFilter === 'All' || p.category === selectedFilter;
    const matchesSearch =
      !searchQuery ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (!p.isAnonymous && p.author.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Dashboard Feed Banner with Community Dialogue Photographic Accent */}
      <div className="overflow-hidden rounded-3xl bg-white border border-slate-200/90 shadow-sm grid grid-cols-1 md:grid-cols-12 items-stretch">
        <div className="md:col-span-7 p-6 sm:p-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 uppercase tracking-wider">
              <MessageSquare className="w-4 h-4" />
              <span>Community Discussions & Support</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
              Community Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">
              A safe space for lived stories, practical advice, and peer solidarity. You can post with your profile or post completely anonymously.
            </p>
          </div>

          <div className="mt-5 flex items-center justify-between gap-4 pt-3 border-t border-slate-100 flex-wrap">
            <span className="text-[11px] text-slate-500 font-medium">
              Respectful peer dialogue & mutual care
            </span>
            <button
              onClick={() => setIsComposerOpen(!isComposerOpen)}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>{isComposerOpen ? 'Close Composer' : 'Create Post'}</span>
            </button>
          </div>
        </div>

        {/* Community Dialogue Photograph */}
        <div className="md:col-span-5 relative min-h-[160px] md:min-h-full bg-slate-100 overflow-hidden border-t md:border-t-0 md:border-l border-slate-200/80">
          <img
            src="/src/assets/images/community_dialogue_1791702631708.jpg"
            alt="Community members engaged in thoughtful, supportive conversation around a wooden table in a sunlit community center"
            className="w-full h-full object-cover object-center"
            loading="eager"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-2.5 left-3 right-3 text-white text-[11px] font-medium leading-tight drop-shadow-xs">
            Respectful dialogue, lived stories & mutual care
          </div>
        </div>
      </div>

      {/* Main Focused Social Feed */}
      <div className="space-y-4">
        {/* Post Composer Card with Anonymous Posting Option */}
        {isComposerOpen && (
          <div className="p-5 sm:p-6 rounded-2xl bg-white border border-blue-200 shadow-sm animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-900">
                Create a Discussion Post
              </span>
              <span className="text-[11px] text-slate-500">
                {isAnonymousMode ? (
                  <span className="text-slate-700 font-semibold flex items-center gap-1">
                    <UserX className="w-3.5 h-3.5 text-emerald-600" /> Posting as Anonymous Member
                  </span>
                ) : (
                  <span className="flex items-center gap-1 font-medium text-slate-700">
                    <User className="w-3.5 h-3.5 text-blue-600" /> Posting as {user.name}
                  </span>
                )}
              </span>
            </div>

            <form onSubmit={handleSubmitPost} className="mt-4 space-y-4">
              {/* 1. Identity Choice: Profile vs. Anonymous */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-600">
                  Author Identity
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <label
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                      !isAnonymousMode
                        ? 'border-blue-500 bg-white text-slate-900 font-semibold shadow-xs'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    <input
                      type="radio"
                      name="posting-identity"
                      checked={!isAnonymousMode}
                      onChange={() => setIsAnonymousMode(false)}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <User className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <span>Post with my profile</span>
                      <span className="block text-[10px] font-normal text-slate-400">
                        Displays: {user.name}
                      </span>
                    </div>
                  </label>

                  <label
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                      isAnonymousMode
                        ? 'border-emerald-500 bg-white text-slate-900 font-semibold shadow-xs'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    <input
                      type="radio"
                      name="posting-identity"
                      checked={isAnonymousMode}
                      onChange={() => setIsAnonymousMode(true)}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <UserX className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span>Post anonymously</span>
                      <span className="block text-[10px] font-normal text-slate-400">
                        Displays: Anonymous Member
                      </span>
                    </div>
                  </label>
                </div>
              </div>

              {/* 2. Title & Category */}
              <div>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Headline or question (e.g. Overcoming cultural pressure / Navigating workplace discrimination)"
                  required
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                  Discussion Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as CommunityPost['category'])}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none"
                >
                  <option value="Shared Story">Shared Story</option>
                  <option value="Legal Question">Legal Question</option>
                  <option value="Reform Idea">Reform Idea</option>
                  <option value="Solidarity">Solidarity & Support</option>
                </select>
              </div>

              {/* 3. Body Content */}
              <div>
                <textarea
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  rows={4}
                  placeholder="Write your story, advice, or question. Never include private phone numbers or addresses..."
                  required
                  className="w-full p-3.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 resize-y leading-relaxed"
                />
              </div>

              {/* 4. Trigger Warning Checkbox */}
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <input
                  type="checkbox"
                  id="tw-inline"
                  checked={hasTriggerWarning}
                  onChange={(e) => setHasTriggerWarning(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="tw-inline" className="cursor-pointer select-none text-[11px]">
                  Content Sensitivity Notice (blurs post until reader clicks to reveal)
                </label>
              </div>

              {/* 5. Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsComposerOpen(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-xs cursor-pointer"
                >
                  {isAnonymousMode ? 'Publish Anonymously' : 'Publish with Profile'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Feed Filter Bar & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto scrollbar-none">
            {filterOptions.map((opt) => (
              <button
                key={opt}
                onClick={() => setSelectedFilter(opt)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                  selectedFilter === opt
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search posts..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Posts List */}
        {filteredPosts.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-2">
            <p className="text-sm font-semibold text-slate-700">No discussion posts match your criteria</p>
            <p className="text-xs text-slate-400">
              Try adjusting your filter or search keywords, or create the first post.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredPosts.map((post) => {
              const isBlurred = post.hasTriggerWarning && !revealedWarnings[post.id];
              const isCommentsOpen = expandedCommentsPostId === post.id;

              return (
                <article
                  key={post.id}
                  className="p-5 sm:p-6 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-3.5 transition-all"
                >
                  {/* Post Top Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                          post.isAnonymous
                            ? 'bg-slate-100 text-slate-600'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        {post.isAnonymous ? <UserX className="w-4 h-4" /> : post.author[0]}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            {post.author}
                          </span>
                          {post.isAnonymous && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium">
                              Protected
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400">{post.date}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200/70">
                        {post.category}
                      </span>
                      <button
                        onClick={() => setReportModalPostId(post.id)}
                        title="Report post for moderation"
                        className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                      >
                        <Flag className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Post Title */}
                  <h2 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                    {post.title}
                  </h2>

                  {/* Trigger warning alert banner */}
                  {post.hasTriggerWarning && isBlurred && (
                    <div className="p-3 rounded-xl bg-amber-50 border border-amber-200/80 flex items-center justify-between text-xs text-amber-900">
                      <span className="flex items-center gap-2 font-medium">
                        <Eye className="w-4 h-4 text-amber-600" /> Content Sensitivity Warning: Sensitive or traumatic experience.
                      </span>
                      <button
                        onClick={() =>
                          setRevealedWarnings((prev) => ({ ...prev, [post.id]: true }))
                        }
                        className="font-bold underline text-amber-800 hover:text-amber-950 cursor-pointer text-[11px]"
                      >
                        Reveal Story
                      </button>
                    </div>
                  )}

                  {/* Content body */}
                  <div className={`relative ${isBlurred ? 'select-none filter blur-sm pointer-events-none' : ''}`}>
                    <p className="text-xs sm:text-sm text-slate-700 whitespace-pre-line leading-relaxed">
                      {post.content}
                    </p>
                  </div>

                  {/* Footer Action Bar */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-4">
                      {/* Heart / Support Button */}
                      <button
                        onClick={() => onToggleSupport(post.id)}
                        className={`flex items-center gap-1.5 font-semibold transition-colors cursor-pointer ${
                          post.hasSupported
                            ? 'text-rose-600'
                            : 'text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        <Heart
                          className={`w-4 h-4 ${
                            post.hasSupported ? 'fill-rose-600 text-rose-600' : ''
                          }`}
                        />
                        <span>{post.supportCount} Support</span>
                      </button>

                      {/* Comment toggle */}
                      <button
                        onClick={() =>
                          setExpandedCommentsPostId(isCommentsOpen ? null : post.id)
                        }
                        className="flex items-center gap-1.5 text-slate-500 hover:text-slate-900 font-semibold cursor-pointer"
                      >
                        <MessageSquare className="w-4 h-4" />
                        <span>{post.comments.length} Replies</span>
                      </button>
                    </div>

                    <span className="text-[10px] text-slate-400">
                      EqualGround Moderated
                    </span>
                  </div>

                  {/* Expandable comments thread */}
                  {isCommentsOpen && (
                    <div className="pt-3 mt-3 border-t border-slate-100 space-y-3">
                      {post.comments.length > 0 && (
                        <div className="space-y-2">
                          {post.comments.map((c) => (
                            <div
                              key={c.id}
                              className="p-3 rounded-xl bg-slate-50 text-xs text-slate-800"
                            >
                              <div className="flex items-center justify-between text-[10px] text-slate-400">
                                <span className="font-semibold text-slate-800">
                                  {c.author}
                                </span>
                                <span>{c.date}</span>
                              </div>
                              <p className="mt-1 text-slate-600 leading-relaxed">
                                {c.content}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Reply box */}
                      <div className="flex items-center gap-2 pt-1">
                        <input
                          type="text"
                          value={commentInputs[post.id] || ''}
                          onChange={(e) =>
                            setCommentInputs((prev) => ({
                              ...prev,
                              [post.id]: e.target.value
                            }))
                          }
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSendComment(post.id);
                          }}
                          placeholder="Write a supportive reply..."
                          className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none"
                        />
                        <button
                          onClick={() => handleSendComment(post.id)}
                          className="p-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </div>

      {/* Report confirmation modal */}
      {reportModalPostId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl p-6 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 mx-auto flex items-center justify-center mb-3">
              <Flag className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Report Community Post
            </h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Does this post violate safety standards by sharing private identifiable information, harassment, or threats?
            </p>
            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setReportModalPostId(null)}
                className="flex-1 py-2 text-xs font-semibold rounded-xl bg-slate-100 text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleReportPost(reportModalPostId)}
                className="flex-1 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-700 text-white cursor-pointer"
              >
                Confirm Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
