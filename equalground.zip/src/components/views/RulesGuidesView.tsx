import React, { useState } from 'react';
import {
  BookOpen,
  Scale,
  Shield,
  Users,
  Lock,
  ChevronDown,
  ChevronUp,
  Search,
  Copy,
  Check,
  ArrowLeft,
  CheckCircle2,
  PhoneCall,
  MapPin,
  ExternalLink,
  AlertCircle
} from 'lucide-react';
import { RightsGuide, PlatformRule, ViewType } from '../../types';
import { COUNTRIES_EMERGENCY_DATA, DEFAULT_COUNTRY_CODE } from '../../data/emergencyData';

interface RulesGuidesViewProps {
  guides: RightsGuide[];
  onBack: () => void;
  onNavigate?: (view: ViewType) => void;
  onShowToast: (title: string, desc?: string, type?: 'success' | 'info' | 'warning') => void;
}

const PLATFORM_RULES: PlatformRule[] = [
  {
    id: 'rule-community-dignity',
    title: 'Community Dignity & Anti-Harassment Standards',
    category: 'community',
    summary: 'Strict zero-tolerance code for victim-blaming, discriminatory attacks, and harassment across discussions.',
    principles: [
      'Every human being has inherent dignity regardless of ethnic background, gender identity, religion, or social class.',
      'Victim-blaming, retaliation, or intimidation of survivors will result in immediate content removal.',
      'Constructive peer support and legal strategy discussions must remain respectful and evidence-grounded.'
    ],
    guidance: 'If you encounter any harassing post or comment, use the inline "Report" button to flag it for community moderators.'
  },
  {
    id: 'rule-anonymity-safety',
    title: 'Anonymous Posting & Personal Privacy Protection',
    category: 'community',
    summary: 'Guidelines for safely sharing lived experiences without exposing yourself or others to surveillance.',
    principles: [
      'Choose "Post anonymously" whenever discussing trauma, workplace retaliation, or sensitive family dynamics.',
      'Never include real full names, employer names, physical addresses, or phone numbers in discussion texts.',
      'Remember that while the public feed shows "Anonymous Member", physical access to your device could reveal browser cache.'
    ],
    guidance: 'Always purge local storage or use Private Browsing mode when operating on monitored or shared family computers.'
  },
  {
    id: 'rule-privacy-storage',
    title: 'Client-Side Local Storage & Transparency Disclosures',
    category: 'privacy',
    summary: 'Honest technical disclosure regarding browser-local memory vs. server encryption.',
    principles: [
      'Your private journal entries and platform settings exist solely in this browser’s local storage.',
      'Zero remote analytics, telemetry, or third-party advertising cookies are transmitted.',
      'Local storage does not provide cross-device synchronization or administrative encryption against physical device inspection.'
    ],
    guidance: 'Use the "Export Session Backup" and "Purge All Data" buttons in Profile Settings before leaving shared workstations.'
  }
];

export const RulesGuidesView: React.FC<RulesGuidesViewProps> = ({
  guides,
  onBack,
  onNavigate,
  onShowToast
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'community' | 'emergency' | 'rights' | 'privacy'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(guides[0]?.id || null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>(DEFAULT_COUNTRY_CODE);
  const [copiedPhone, setCopiedPhone] = useState<string | null>(null);

  const filterTabs: { id: 'all' | 'community' | 'emergency' | 'rights' | 'privacy'; label: string }[] = [
    { id: 'all', label: 'All Rules & Guides' },
    { id: 'community', label: 'Community Standards' },
    { id: 'emergency', label: 'Emergency Help & Support' },
    { id: 'rights', label: 'Rights Guides (Legal Protections)' },
    { id: 'privacy', label: 'Privacy & Security Guidance' }
  ];

  const selectedCountry =
    COUNTRIES_EMERGENCY_DATA.find((c) => c.countryCode === selectedCountryCode) ||
    COUNTRIES_EMERGENCY_DATA[0];

  const handleCopyPhone = (number: string, serviceName: string) => {
    navigator.clipboard.writeText(number).then(() => {
      setCopiedPhone(number);
      onShowToast('Phone Number Copied', `${serviceName}: ${number} copied to clipboard.`, 'success');
      setTimeout(() => setCopiedPhone(null), 2500);
    });
  };

  const copyActionPlan = (guide: RightsGuide) => {
    const planText = `[EQUALGROUND ACTION PLAN: ${guide.title}]\n\nSummary:\n${guide.summary}\n\nKey Legal Protections:\n${guide.legalBasis}\n\nImmediate Action Steps:\n${guide.actionSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}\n\nVerified Resources:\n${guide.resources.map(r => `${r.name}: ${r.contact}`).join('\n')}`;

    navigator.clipboard.writeText(planText).then(() => {
      setCopiedId(guide.id);
      onShowToast('Action Plan Copied', 'Plain text copied safely to clipboard.', 'success');
      setTimeout(() => setCopiedId(null), 2500);
    });
  };

  // Visibility flags based on activeTab and searchQuery
  const showCommunity = activeTab === 'all' || activeTab === 'community';
  const showEmergency = activeTab === 'all' || activeTab === 'emergency';
  const showRights = activeTab === 'all' || activeTab === 'rights';
  const showPrivacy = activeTab === 'all' || activeTab === 'privacy';

  const matchesSearch = (text: string) => {
    if (!searchQuery) return true;
    return text.toLowerCase().includes(searchQuery.toLowerCase());
  };

  const filteredCommunityRules = PLATFORM_RULES.filter(
    (r) => r.category === 'community' && (matchesSearch(r.title) || matchesSearch(r.summary) || matchesSearch('community standards'))
  );

  const filteredPrivacyRules = PLATFORM_RULES.filter(
    (r) => r.category === 'privacy' && (matchesSearch(r.title) || matchesSearch(r.summary) || matchesSearch('privacy security storage'))
  );

  const filteredGuides = guides.filter(
    (g) => matchesSearch(g.title) || matchesSearch(g.summary) || matchesSearch(g.legalBasis) || matchesSearch(g.category)
  );

  const matchesEmergencySearch =
    matchesSearch('emergency help') ||
    matchesSearch('crisis hotline') ||
    matchesSearch('local emergency contacts') ||
    matchesSearch(selectedCountry.countryName) ||
    selectedCountry.services.some((s) => matchesSearch(s.service) || matchesSearch(s.number));

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Top Breadcrumb and Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Profile</span>
        </button>

        <span className="text-[11px] font-medium text-slate-500">
          Profile → Rules & Guides
        </span>
      </div>

      {/* Section Header with Photographic Banner */}
      <div className="overflow-hidden rounded-3xl bg-white border border-slate-200/90 shadow-sm grid grid-cols-1 md:grid-cols-12 items-stretch">
        <div className="md:col-span-7 p-6 sm:p-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-blue-700 uppercase tracking-wider">
              <BookOpen className="w-4 h-4" />
              <span>Profile · Rules & Guides Hub</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
              Rules & Guides
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">
              Comprehensive legal rights guides, international statutes, community standards, and emergency help resources gathered in one trusted place.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-[11px] text-slate-500">
            <Scale className="w-3.5 h-3.5 text-blue-700" />
            <span>Universal Declaration of Human Rights & Verified Support Services</span>
          </div>
        </div>

        {/* Civic Hall Library Photograph */}
        <div className="md:col-span-5 relative min-h-[180px] md:min-h-full bg-slate-100 overflow-hidden border-t md:border-t-0 md:border-l border-slate-200/80">
          <img
            src="/src/assets/images/human_rights_guide_1791702621817.jpg"
            alt="Modern sunlit civic hall library symbolizing open justice, education, equality, and universal dignity"
            className="w-full h-full object-cover object-center"
            loading="eager"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-2.5 left-3 right-3 text-white text-[11px] font-medium leading-tight drop-shadow-xs">
            Open justice, rights education, and human dignity
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto scrollbar-none">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search rules, guides & contacts..."
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      <div className="space-y-6">
        {/* =========================================================================
            SECTION 1: COMMUNITY STANDARDS (MOVED & ORGANIZED FROM DASHBOARD)
           ========================================================================= */}
        {showCommunity && (
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-700" />
                <h2 className="text-base font-bold text-slate-900">
                  Community Standards
                </h2>
              </div>
              <span className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider">
                EqualGround Code of Conduct
              </span>
            </div>

            {/* Prominent Community Ground Rules Highlight Box */}
            <div className="p-5 sm:p-6 rounded-2xl bg-white border border-emerald-200/90 shadow-2xs space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
                    <span>Community Ground Rules</span>
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    EqualGround enforces core safety principles to maintain a supportive, survivor-safe space across all community discussions.
                  </p>
                </div>
                <span className="text-[11px] px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 font-bold border border-emerald-200 shrink-0">
                  Mandatory Standards
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                {/* Principle 1 */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Zero Tolerance</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Zero tolerance for victim-blaming, harassment, intimidation, or discriminatory attacks against any member.
                  </p>
                </div>

                {/* Principle 2 */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Protect Personal Info</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Never share phone numbers, email addresses, or personal locations publicly in discussion posts or comments.
                  </p>
                </div>

                {/* Principle 3 */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Anonymous Option</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Choose "Post anonymously" whenever discussing sensitive trauma, workplace retaliation, or legal vulnerability.
                  </p>
                </div>
              </div>
            </div>

            {/* Detailed Community Standards Accordions */}
            <div className="space-y-3">
              {filteredCommunityRules.map((rule) => {
                const isExpanded = expandedId === rule.id;
                return (
                  <div
                    key={rule.id}
                    className="rounded-2xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden"
                  >
                    <div
                      onClick={() => setExpandedId(isExpanded ? null : rule.id)}
                      className="p-5 cursor-pointer flex items-start justify-between gap-4 hover:bg-slate-50 transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="text-[11px] font-medium text-slate-500 flex items-center gap-2">
                          <span className="uppercase tracking-wider font-bold text-emerald-700">
                            Community Standard
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>EqualGround Core Code</span>
                        </div>
                        <h3 className="mt-1 text-base font-bold text-slate-900">
                          {rule.title}
                        </h3>
                        <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                          {rule.summary}
                        </p>
                      </div>
                      <button
                        className="p-1 text-slate-400 rounded-lg shrink-0 pt-1"
                        aria-label={isExpanded ? 'Collapse rule' : 'Expand rule'}
                      >
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </button>
                    </div>

                    {isExpanded && (
                      <div className="px-5 pb-5 pt-2 border-t border-slate-100 space-y-4 text-xs">
                        <div>
                          <h4 className="font-bold text-slate-500 uppercase tracking-wider mb-2">
                            Core Principles
                          </h4>
                          <ul className="space-y-2">
                            {rule.principles.map((p, idx) => (
                              <li key={idx} className="flex items-start gap-2.5 text-slate-700 leading-relaxed">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                                <span>{p}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="p-3 rounded-xl bg-slate-50 text-slate-700 leading-relaxed border border-slate-200/80">
                          <strong className="text-slate-900">Recommended Guidance:</strong> {rule.guidance}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* =========================================================================
            SECTION 2: EMERGENCY HELP & SUPPORT (MOVED & ORGANIZED FROM DASHBOARD)
           ========================================================================= */}
        {showEmergency && matchesEmergencySearch && (
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <div className="flex items-center gap-2">
                <PhoneCall className="w-5 h-5 text-rose-600" />
                <h2 className="text-base font-bold text-slate-900">
                  Emergency Help & Support
                </h2>
              </div>
              <span className="text-[11px] font-semibold text-rose-600 uppercase tracking-wider">
                24/7 Verified Dispatch
              </span>
            </div>

            {/* Interactive Location-Based Emergency Help Card */}
            <div className="p-5 sm:p-6 rounded-2xl bg-white border border-rose-200/90 shadow-2xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-rose-700">
                    <AlertCircle className="w-4 h-4" />
                    <span>Need Emergency Help?</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed max-w-xl">
                    Access verified emergency dispatch and crisis lines specific to your country. Immediate help for police, medical, fire rescue, and confidential survivor lifelines.
                  </p>
                </div>

                {onNavigate && (
                  <button
                    onClick={() => onNavigate('emergency')}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer shrink-0 self-start sm:self-auto"
                  >
                    <span>View Local Emergency Contacts</span>
                    <span>→</span>
                  </button>
                )}
              </div>

              {/* Location Emergency Selector & Live Phone Directory */}
              <div className="p-4 rounded-xl bg-rose-50/40 border border-rose-100 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-rose-600" />
                    <span>Location-Based Crisis Numbers:</span>
                  </label>

                  <select
                    value={selectedCountryCode}
                    onChange={(e) => setSelectedCountryCode(e.target.value)}
                    className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:border-rose-500 font-medium"
                  >
                    {COUNTRIES_EMERGENCY_DATA.map((c) => (
                      <option key={c.countryCode} value={c.countryCode}>
                        {c.flag} {c.countryName} ({c.primaryNumber})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Country Primary Services Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {selectedCountry.services.slice(0, 4).map((srv, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg bg-white border border-rose-100 flex items-center justify-between gap-2 shadow-2xs"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 truncate">
                          {srv.service}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">
                          {srv.description}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="font-mono font-bold text-xs text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                          {srv.number}
                        </span>
                        <button
                          onClick={() => handleCopyPhone(srv.number, srv.service)}
                          title="Copy number"
                          className="p-1 text-slate-400 hover:text-slate-800 rounded transition-colors cursor-pointer"
                        >
                          {copiedPhone === srv.number ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                  <span>{selectedCountry.dialingNotes}</span>
                  {onNavigate && (
                    <button
                      onClick={() => onNavigate('emergency')}
                      className="text-rose-700 font-bold hover:underline cursor-pointer"
                    >
                      View all {selectedCountry.services.length} services for {selectedCountry.countryName} →
                    </button>
                  )}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* =========================================================================
            SECTION 3: RIGHTS GUIDES (LEGAL PROTECTIONS & STATUTES)
           ========================================================================= */}
        {showRights && (
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-blue-700" />
                <h2 className="text-base font-bold text-slate-900">
                  Legal Rights & Statutory Guides
                </h2>
              </div>
              <span className="text-[11px] font-semibold text-blue-700 uppercase tracking-wider">
                International Protections
              </span>
            </div>

            <div className="space-y-3">
              {filteredGuides.map((guide) => {
                const isExpanded = expandedId === guide.id;
                return (
                  <div
                    key={guide.id}
                    className="rounded-2xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden"
                  >
                    <div
                      onClick={() => setExpandedId(isExpanded ? null : guide.id)}
                      className="p-5 cursor-pointer flex items-start justify-between gap-4 hover:bg-slate-50 transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="text-[11px] font-medium text-slate-500 flex items-center gap-2">
                          <span className="uppercase tracking-wider font-bold text-blue-700">
                            {guide.category} Rights Guide
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>International Protection</span>
                        </div>
                        <h3 className="mt-1 text-base font-bold text-slate-900">
                          {guide.title}
                        </h3>
                        <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                          {guide.summary}
                        </p>
                      </div>
                      <button
                        className="p-1 text-slate-400 rounded-lg shrink-0 pt-1"
                        aria-label={isExpanded ? 'Collapse guide' : 'Expand guide'}
                      >
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </button>
                    </div>

                    {isExpanded && (
                      <div className="px-5 pb-5 pt-2 border-t border-slate-100 space-y-4 text-xs">
                        {/* Binding Legal Basis */}
                        <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-100 text-blue-950">
                          <p className="font-semibold flex items-center gap-1.5">
                            <Scale className="w-3.5 h-3.5 text-blue-700" />
                            <span>Binding Legal Standard</span>
                          </p>
                          <p className="mt-0.5 text-blue-900/90 leading-relaxed">
                            {guide.legalBasis}
                          </p>
                        </div>

                        {/* Principles */}
                        <div>
                          <h4 className="font-bold text-slate-500 uppercase tracking-wider mb-2">
                            Key Autonomy Principles
                          </h4>
                          <ul className="space-y-1.5">
                            {guide.fullContent.map((point, index) => (
                              <li key={index} className="flex items-start gap-2 text-slate-700 leading-relaxed">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0 mt-1.5" />
                                <span>{point}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Action Steps */}
                        <div>
                          <h4 className="font-bold text-slate-500 uppercase tracking-wider mb-2">
                            Action Steps
                          </h4>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {guide.actionSteps.map((step, idx) => (
                              <div
                                key={idx}
                                className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-2 text-slate-800"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                                <span>{step}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Verified Resources */}
                        <div>
                          <h4 className="font-bold text-slate-500 uppercase tracking-wider mb-2">
                            Verified Contacts
                          </h4>
                          <div className="space-y-1.5">
                            {guide.resources.map((res, i) => (
                              <div
                                key={i}
                                className="p-2.5 rounded-xl border border-slate-200/90 bg-white flex items-center justify-between text-slate-800"
                              >
                                <div>
                                  <p className="font-semibold flex items-center gap-1.5">
                                    {res.isHotline && <PhoneCall className="w-3 h-3 text-rose-500" />}
                                    <span>{res.name}</span>
                                  </p>
                                  <p className="text-slate-500 font-mono text-[11px] mt-0.5">{res.contact}</p>
                                </div>
                                <span className="text-[10px] text-slate-400">Verified</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Copy Button */}
                        <div className="flex justify-end pt-1">
                          <button
                            onClick={() => copyActionPlan(guide)}
                            className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            {copiedId === guide.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Action Plan Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy Action Plan</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* =========================================================================
            SECTION 4: PRIVACY & SECURITY GUIDANCE
           ========================================================================= */}
        {showPrivacy && (
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-sky-700" />
                <h2 className="text-base font-bold text-slate-900">
                  Privacy & Security Protocols
                </h2>
              </div>
              <span className="text-[11px] font-semibold text-sky-700 uppercase tracking-wider">
                Local Storage & Surveillance Defense
              </span>
            </div>

            <div className="space-y-3">
              {filteredPrivacyRules.map((rule) => {
                const isExpanded = expandedId === rule.id;
                return (
                  <div
                    key={rule.id}
                    className="rounded-2xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden"
                  >
                    <div
                      onClick={() => setExpandedId(isExpanded ? null : rule.id)}
                      className="p-5 cursor-pointer flex items-start justify-between gap-4 hover:bg-slate-50 transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="text-[11px] font-medium text-slate-500 flex items-center gap-2">
                          <span className="uppercase tracking-wider font-bold text-sky-700">
                            Privacy Protocol
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>EqualGround Core Code</span>
                        </div>
                        <h3 className="mt-1 text-base font-bold text-slate-900">
                          {rule.title}
                        </h3>
                        <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                          {rule.summary}
                        </p>
                      </div>
                      <button
                        className="p-1 text-slate-400 rounded-lg shrink-0 pt-1"
                        aria-label={isExpanded ? 'Collapse rule' : 'Expand rule'}
                      >
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </button>
                    </div>

                    {isExpanded && (
                      <div className="px-5 pb-5 pt-2 border-t border-slate-100 space-y-4 text-xs">
                        <div>
                          <h4 className="font-bold text-slate-500 uppercase tracking-wider mb-2">
                            Core Principles
                          </h4>
                          <ul className="space-y-2">
                            {rule.principles.map((p, idx) => (
                              <li key={idx} className="flex items-start gap-2.5 text-slate-700 leading-relaxed">
                                <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                                <span>{p}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="p-3 rounded-xl bg-slate-50 text-slate-700 leading-relaxed border border-slate-200/80">
                          <strong className="text-slate-900">Recommended Guidance:</strong> {rule.guidance}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Empty state when search yields nothing */}
        {!showCommunity && !showEmergency && !showRights && !showPrivacy && (
          <div className="p-8 text-center rounded-2xl bg-white border border-slate-200/90 text-slate-400 text-xs">
            No rules or guides found matching your query.
          </div>
        )}
      </div>
    </div>
  );
};
