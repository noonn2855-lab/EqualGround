import React from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Scale,
  MessageSquare,
  BookHeart,
  Megaphone,
  Shield,
  PhoneCall,
  Info
} from 'lucide-react';
import { FeatureKey, ViewType } from '../../types';
import { FEATURES_METADATA } from '../../data/featureMetadata';

interface FeatureIntroViewProps {
  featureKey: FeatureKey;
  onBack: () => void;
  onContinue: (targetView: ViewType, featureKey: FeatureKey) => void;
}

export const FeatureIntroView: React.FC<FeatureIntroViewProps> = ({
  featureKey,
  onBack,
  onContinue
}) => {
  const metadata = FEATURES_METADATA[featureKey] || FEATURES_METADATA.dashboard;

  const renderIcon = (name: string) => {
    switch (name) {
      case 'Scale':
        return <Scale className="w-8 h-8 text-blue-700" />;
      case 'MessageSquare':
        return <MessageSquare className="w-8 h-8 text-emerald-600" />;
      case 'BookHeart':
        return <BookHeart className="w-8 h-8 text-sky-600" />;
      case 'Megaphone':
        return <Megaphone className="w-8 h-8 text-blue-700" />;
      case 'Shield':
        return <Shield className="w-8 h-8 text-slate-600" />;
      case 'PhoneCall':
        return <PhoneCall className="w-8 h-8 text-rose-600" />;
      default:
        return <Info className="w-8 h-8 text-blue-700" />;
    }
  };

  const getFeatureImage = (key: FeatureKey) => {
    switch (key) {
      case 'dashboard':
        return {
          src: '/src/assets/images/community_dialogue_1791702631708.jpg',
          alt: 'Community members engaged in thoughtful, supportive dialogue around a wooden table',
          caption: 'Safe community discussions and peer solidarity'
        };
      case 'journal':
        return {
          src: '/src/assets/images/privacy_journal_vault_1791702642961.jpg',
          alt: 'Open personal journal with fountain pen on a wooden desk in natural morning light',
          caption: 'Confidential client-side private journaling'
        };
      case 'changelab':
        return {
          src: '/src/assets/images/civic_reform_changelab_1791702665381.jpg',
          alt: 'Civic volunteers and advocates collaborating on community initiatives and reform blueprints',
          caption: 'Democratic policy proposals and community campaigns'
        };
      case 'emergency':
        return {
          src: '/src/assets/images/emergency_support_1791702653544.jpg',
          alt: 'Reassuring emergency care helpline counselor providing immediate human assistance',
          caption: 'Verified emergency numbers and 24/7 crisis support'
        };
      case 'settings':
      default:
        return {
          src: '/src/assets/images/privacy_journal_vault_1791702642961.jpg',
          alt: 'Peaceful desk symbolizing privacy, safety, and client-side device boundaries',
          caption: 'Profile identity, Rules & Guides, and local storage controls'
        };
    }
  };

  const featureImg = getFeatureImage(featureKey);

  return (
    <div className="max-w-3xl mx-auto py-6 sm:py-10 animate-in fade-in duration-200 space-y-6">
      {/* Top back link */}
      <div>
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
      </div>

      {/* Main card */}
      <div className="overflow-hidden rounded-3xl bg-white border border-slate-200/90 shadow-sm space-y-6">
        {/* Photographic Hero Banner */}
        <div className="relative aspect-16/9 sm:aspect-21/9 max-h-64 overflow-hidden bg-slate-100 border-b border-slate-100">
          <img
            src={featureImg.src}
            alt={featureImg.alt}
            className="w-full h-full object-cover object-center"
            loading="eager"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-3 left-4 right-4 text-white text-xs font-medium">
            {featureImg.caption}
          </div>
        </div>

        <div className="p-6 sm:p-8 pt-0 space-y-6">
          {/* Header with Icon and Title */}
          <div className="flex items-start gap-4 sm:gap-5">
            <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center shrink-0 shadow-xs border border-slate-200/80">
              {renderIcon(metadata.iconName)}
            </div>
            <div>
              <span className="text-[11px] font-bold tracking-wider uppercase text-blue-700">
                Feature Overview & Guide
              </span>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 mt-0.5">
                {metadata.title}
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                {metadata.shortDescription}
              </p>
            </div>
          </div>

          {/* Section 1: What this feature does */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              What this feature does
            </h2>
            <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
              {metadata.whatItDoes}
            </p>
          </div>

          {/* Section 2: Step-by-step instructions */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              How to use it
            </h2>
            <div className="space-y-2.5">
              {metadata.instructions.map((step, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-start gap-3"
                >
                  <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                    {step}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons: Continue & Back */}
          <div className="pt-4 border-t border-slate-100 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
            <button
              onClick={onBack}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Home</span>
            </button>

            <button
              onClick={() => onContinue(metadata.targetView, metadata.key)}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Enter {metadata.title}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
