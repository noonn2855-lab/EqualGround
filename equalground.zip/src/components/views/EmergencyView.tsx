import React, { useState } from 'react';
import {
  PhoneCall,
  MapPin,
  AlertCircle,
  Search,
  Copy,
  Check,
  ArrowLeft
} from 'lucide-react';
import { COUNTRIES_EMERGENCY_DATA, DEFAULT_COUNTRY_CODE } from '../../data/emergencyData';
import { ViewType } from '../../types';

interface EmergencyViewProps {
  onShowToast: (title: string, desc?: string, type?: 'success' | 'info' | 'warning') => void;
  onNavigate?: (view: ViewType) => void;
  onBack?: () => void;
}

export const EmergencyView: React.FC<EmergencyViewProps> = ({ onShowToast, onNavigate, onBack }) => {
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>(DEFAULT_COUNTRY_CODE);
  const [searchFilter, setSearchFilter] = useState('');
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  const selectedCountry =
    COUNTRIES_EMERGENCY_DATA.find((c) => c.countryCode === selectedCountryCode) ||
    COUNTRIES_EMERGENCY_DATA[0];

  const filteredCountries = COUNTRIES_EMERGENCY_DATA.filter((c) =>
    c.countryName.toLowerCase().includes(searchFilter.toLowerCase()) ||
    c.countryCode.toLowerCase().includes(searchFilter.toLowerCase())
  );

  const handleCopyNumber = (num: string, serviceName: string) => {
    navigator.clipboard.writeText(num).then(() => {
      setCopiedNumber(num);
      onShowToast('Phone Number Copied', `${serviceName}: ${num} copied to clipboard.`, 'success');
      setTimeout(() => setCopiedNumber(null), 2500);
    });
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'police':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'medical':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'fire':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'helpline':
        return 'bg-sky-50 text-sky-700 border-sky-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Top Breadcrumb and Back Button */}
      {onBack && (
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Rules & Guides</span>
          </button>

          <span className="text-[11px] font-medium text-slate-500">
            Profile → Rules & Guides → Local Emergency Contacts
          </span>
        </div>
      )}

      {/* Reassuring Header Banner with Counselor Photograph */}
      <div className="overflow-hidden rounded-3xl bg-white border border-slate-200/90 shadow-sm grid grid-cols-1 md:grid-cols-12 items-stretch">
        <div className="md:col-span-7 p-6 sm:p-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-rose-600 uppercase tracking-wider">
              <PhoneCall className="w-4 h-4" />
              <span>Location-Specific Emergency Contacts</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
              Emergency Services by Country
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">
              Verified local emergency numbers for police, medical, fire rescue, and crisis helplines. Connect directly with specialized, trained counselors and local responders.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-[11px] text-slate-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Crisis helplines and dispatch available 24/7 without carrier fees</span>
          </div>
        </div>

        {/* Reassuring Emergency Counselor Photograph */}
        <div className="md:col-span-5 relative min-h-[180px] md:min-h-full bg-slate-100 overflow-hidden border-t md:border-t-0 md:border-l border-slate-200/80">
          <img
            src="/src/assets/images/emergency_support_1791702653544.jpg"
            alt="Reassuring emergency care helpline counselor providing immediate assistance and human support"
            className="w-full h-full object-cover object-center"
            loading="eager"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-2.5 left-3 right-3 text-white text-[11px] font-medium leading-tight drop-shadow-xs">
            Trained counselors ready for crisis assistance
          </div>
        </div>
      </div>

      {/* Location Selector Card */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <label className="text-xs font-bold text-slate-800 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-blue-600" />
            <span>Select Your Location / Country</span>
          </label>
          <span className="text-xs font-medium text-slate-500">
            Currently showing: <strong className="text-slate-900">{selectedCountry.flag} {selectedCountry.countryName}</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Country Selector Dropdown */}
          <div>
            <select
              value={selectedCountryCode}
              onChange={(e) => setSelectedCountryCode(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 font-medium"
              aria-label="Select Country"
            >
              {COUNTRIES_EMERGENCY_DATA.map((c) => (
                <option key={c.countryCode} value={c.countryCode}>
                  {c.flag} {c.countryName} (Primary: {c.primaryNumber})
                </option>
              ))}
            </select>
          </div>

          {/* Quick filter search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="Search other countries..."
              className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
        </div>

        {searchFilter && (
          <div className="flex flex-wrap gap-1.5 pt-2">
            {filteredCountries.map((c) => (
              <button
                key={c.countryCode}
                onClick={() => {
                  setSelectedCountryCode(c.countryCode);
                  setSearchFilter('');
                }}
                className="px-2.5 py-1 text-xs rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
              >
                {c.flag} {c.countryName}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Primary Emergency Banner for Selected Country */}
      <div className="p-6 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Primary Nationwide Dispatch · {selectedCountry.countryName}
          </span>
          <p className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mt-1 font-mono">
            {selectedCountry.primaryNumber}
          </p>
          {selectedCountry.dialingNotes && (
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              {selectedCountry.dialingNotes}
            </p>
          )}
        </div>

        <button
          onClick={() => handleCopyNumber(selectedCountry.primaryNumber, `${selectedCountry.countryName} Emergency`)}
          className="px-4 py-2.5 rounded-xl bg-white text-slate-900 hover:bg-slate-100 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer self-start sm:self-auto shrink-0 transition-colors shadow-xs"
        >
          {copiedNumber === selectedCountry.primaryNumber ? (
            <>
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>Copy {selectedCountry.primaryNumber}</span>
            </>
          )}
        </button>
      </div>

      {/* Services List for Selected Country */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 px-1">
          Detailed Emergency Services & Specialized Helplines
        </h2>

        <div className="space-y-3">
          {selectedCountry.services.map((item, index) => (
            <div
              key={index}
              className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-300 transition-colors"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-bold text-slate-900">
                    {item.service}
                  </h3>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getTypeBadge(item.type)} uppercase tracking-wider`}>
                    {item.type}
                  </span>
                </div>
                {item.description && (
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {item.description}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-3 pt-2 sm:pt-0 self-start sm:self-auto shrink-0">
                <span className="text-base sm:text-lg font-mono font-bold text-slate-900">
                  {item.number}
                </span>
                <button
                  onClick={() => handleCopyNumber(item.number, item.service)}
                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                  title="Copy number"
                  aria-label={`Copy number for ${item.service}`}
                >
                  {copiedNumber === item.number ? (
                    <Check className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Unverified / Unknown Location Guidance */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex items-start gap-3 text-xs text-slate-600 leading-relaxed">
        <AlertCircle className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold text-slate-900">
            Cannot find your country or operating in an unverified area?
          </p>
          <p className="mt-1">
            Do not guess emergency phone numbers. In most GSM mobile networks across the world, dialing either <strong>112</strong> or <strong>911</strong> will automatically route to the nearest local emergency dispatch center even without mobile credit. Confirm your municipality's direct police or hospital numbers upon arrival.
          </p>
        </div>
      </div>
    </div>
  );
};
