import React from 'react';
import {
  MessageSquare,
  BookHeart,
  Megaphone,
  Shield,
  PhoneCall,
  ArrowRight,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { UserProfile, FeatureKey } from '../../types';
import { FEATURES_METADATA } from '../../data/featureMetadata';

interface HomeViewProps {
  user: UserProfile;
  onSelectFeatureBox: (featureKey: FeatureKey) => void;
  onNavigateToDashboard: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  user,
  onSelectFeatureBox,
  onNavigateToDashboard
}) => {
  const featureBoxes: {
    key: FeatureKey;
    icon: React.ReactNode;
    badge: string;
    accentBorder: string;
    accentBg: string;
    actionText: string;
  }[] = [
    {
      key: 'dashboard',
      icon: <MessageSquare className="w-6 h-6 text-emerald-600" />,
      badge: 'Social Feed & Care',
      accentBorder: 'hover:border-emerald-300',
      accentBg: 'bg-emerald-50 text-emerald-700',
      actionText: 'Open Community Feed'
    },
    {
      key: 'journal',
      icon: <BookHeart className="w-6 h-6 text-sky-600" />,
      badge: '100% Local & Private',
      accentBorder: 'hover:border-sky-300',
      accentBg: 'bg-sky-50 text-sky-700',
      actionText: 'Access Safe Journal'
    },
    {
      key: 'changelab',
      icon: <Megaphone className="w-6 h-6 text-blue-700" />,
      badge: 'Civic Advocacy',
      accentBorder: 'hover:border-blue-300',
      accentBg: 'bg-blue-50 text-blue-700',
      actionText: 'View Reform Campaigns'
    },
    {
      key: 'settings',
      icon: <Shield className="w-6 h-6 text-slate-600" />,
      badge: 'Security & Profile',
      accentBorder: 'hover:border-slate-400',
      accentBg: 'bg-slate-100 text-slate-700',
      actionText: 'Manage Privacy & Rules'
    },
    {
      key: 'emergency',
      icon: <PhoneCall className="w-6 h-6 text-rose-600" />,
      badge: 'Location Contacts',
      accentBorder: 'hover:border-rose-300',
      accentBg: 'bg-rose-50 text-rose-700',
      actionText: 'View Emergency Contacts'
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Welcoming Community Hero Banner with Authentic Photography */}
      <div className="overflow-hidden rounded-3xl bg-white border border-slate-200/90 shadow-sm grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-blue-700 uppercase">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>EqualGround · Authenticated Workspace</span>
            </div>

            <h1 className="mt-2 text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
              Welcome to EqualGround, {user.name}
            </h1>

            <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
              A community founded on dignity, mutual protection, and human rights. Review plain-language legal frameworks, keep private device-only notes, and participate in peer discussions safely.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={onNavigateToDashboard}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-xs transition-colors shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Open Community Dashboard</span>
            </button>
            <span className="text-xs text-slate-500">
              {user.isGuest ? 'Protected guest session active' : 'Verified member session'}
            </span>
          </div>
        </div>

        {/* Natural Community Photograph */}
        <div className="lg:col-span-5 relative min-h-[220px] lg:min-h-full bg-slate-100 overflow-hidden border-t lg:border-t-0 lg:border-l border-slate-200/80">
          <img
            src="/src/assets/images/home_community_hero_1791702610169.jpg"
            alt="Supportive community members gathered outdoors in respectful dialogue and shared solidarity"
            className="w-full h-full object-cover object-center"
            loading="eager"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-3 left-4 right-4 text-white text-[11px] font-medium leading-tight drop-shadow-xs">
            Community gathered in open, respectful dialogue
          </div>
        </div>
      </div>

      {/* Feature Boxes Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              Platform Features & Sections
            </h2>
            <p className="text-xs text-slate-500">
              Click any box to review instructions before entering the feature.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {featureBoxes.map((box) => {
            const meta = FEATURES_METADATA[box.key];
            return (
              <div
                key={box.key}
                onClick={() => onSelectFeatureBox(box.key)}
                className={`group p-6 rounded-2xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between ${box.accentBorder}`}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onSelectFeatureBox(box.key);
                  }
                }}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-center shadow-xs">
                      {box.icon}
                    </div>
                    <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${box.accentBg}`}>
                      {box.badge}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                    {meta.title}
                  </h3>

                  <p className="mt-2 text-xs text-slate-600 leading-relaxed line-clamp-3">
                    {meta.shortDescription}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-700">
                  <span>View Instructions & Enter</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Human Rights Foundation Note */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex items-center gap-3 text-xs text-slate-600">
        <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
        <p className="leading-relaxed">
          <strong className="text-slate-900">Article 1, UDHR:</strong> All human beings are born free and equal in dignity and rights. Regardless of race, gender, heritage, or status, you have the right to live without violence, coercion, or discrimination.
        </p>
      </div>
    </div>
  );
};
