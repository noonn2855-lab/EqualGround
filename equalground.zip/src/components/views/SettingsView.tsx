import React, { useState } from 'react';
import {
  Shield,
  Trash2,
  Download,
  Lock,
  LogIn,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  Scale,
  ArrowRight,
  ChevronRight,
  Users
} from 'lucide-react';
import { UserProfile, ViewType } from '../../types';

interface SettingsViewProps {
  user: UserProfile;
  onOpenLogin: () => void;
  onSignOut: () => void;
  onClearAllData: () => void;
  onShowToast: (title: string, desc?: string, type?: 'success' | 'info' | 'warning') => void;
  onNavigate?: (view: ViewType) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  user,
  onOpenLogin,
  onSignOut,
  onClearAllData,
  onShowToast,
  onNavigate
}) => {
  const [showWipeConfirm, setShowWipeConfirm] = useState(false);

  const handleExportAll = () => {
    const data = {
      exportTimestamp: new Date().toISOString(),
      user: {
        name: user.name,
        isGuest: user.isGuest,
        joinedDate: user.joinedDate
      },
      settings: {
        format: 'Client-Side Local Vault v1.2'
      }
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `EqualGround-Export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onShowToast('Data Exported', 'Session preferences and local metadata downloaded.', 'success');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200 max-w-4xl mx-auto">
      {/* Header */}
      <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
        <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-sky-400 uppercase tracking-wider">
          <Shield className="w-4 h-4" />
          <span>Profile & Privacy Center</span>
        </div>
        <h1 className="mt-1 text-xl sm:text-2xl font-bold text-neutral-900 dark:text-neutral-100">
          User Profile & Settings
        </h1>
        <p className="mt-1 text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 leading-relaxed">
          Manage your account profile, access all platform Rules & Guides, customize appearance, and control local data retention.
        </p>
      </div>

      {/* 1. Account & Session Status */}
      <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
        <div>
          <h2 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
            Account & Session Identity
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            Your active identity within this EqualGround session.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200 dark:border-neutral-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
              {user.avatarSeed}
            </div>
            <div>
              <p className="text-sm font-bold text-neutral-900 dark:text-neutral-100">{user.name}</p>
              <p className="text-xs text-neutral-500">
                {user.isGuest ? 'Guest Session (Protected temporary identity)' : user.email || 'Registered Advocate'}
              </p>
              <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium mt-0.5">
                • {user.joinedDate}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {user.isGuest ? (
              <button
                onClick={onOpenLogin}
                className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In / Register</span>
              </button>
            ) : (
              <button
                onClick={onSignOut}
                className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors cursor-pointer"
              >
                <span>Log Out</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 2. Rules & Guides Section inside Profile */}
      <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2 text-blue-600 dark:text-sky-400">
              <BookOpen className="w-4 h-4" />
              <h2 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                Rules & Guides
              </h2>
            </div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Legal rights frameworks, community conduct rules, and privacy safety protocols gathered into your profile.
            </p>
          </div>

          {onNavigate && (
            <button
              onClick={() => onNavigate('rules-guides')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-sky-950/40 text-blue-700 dark:text-sky-300 text-xs font-bold hover:bg-blue-100 dark:hover:bg-sky-900/60 transition-colors cursor-pointer self-start sm:self-auto"
            >
              <span>Open Rules & Guides Hub</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Directory Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          {/* Rights Guides */}
          <div
            onClick={() => onNavigate?.('rules-guides')}
            className="p-4 rounded-xl border border-neutral-200/80 dark:border-neutral-700/80 bg-neutral-50/50 dark:bg-neutral-800/40 hover:border-blue-300 dark:hover:border-blue-600 transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-sky-400 flex items-center justify-center mb-2.5">
              <Scale className="w-4 h-4" />
            </div>
            <h3 className="text-xs font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-blue-600 dark:group-hover:text-sky-400 transition-colors flex items-center justify-between">
              <span>Rights Guides</span>
              <ChevronRight className="w-3.5 h-3.5 text-neutral-400 group-hover:translate-x-0.5 transition-transform" />
            </h3>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 leading-relaxed">
              Legal protections covering sexual violence, workplace retaliation, coercive practices, and universal equality.
            </p>
          </div>

          {/* Community Rules */}
          <div
            onClick={() => onNavigate?.('rules-guides')}
            className="p-4 rounded-xl border border-neutral-200/80 dark:border-neutral-700/80 bg-neutral-50/50 dark:bg-neutral-800/40 hover:border-emerald-300 dark:hover:border-emerald-600 transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-2.5">
              <Users className="w-4 h-4" />
            </div>
            <h3 className="text-xs font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors flex items-center justify-between">
              <span>Community Ground Rules</span>
              <ChevronRight className="w-3.5 h-3.5 text-neutral-400 group-hover:translate-x-0.5 transition-transform" />
            </h3>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 leading-relaxed">
              Dignity standards, zero tolerance for harassment or victim-blaming, and anonymous posting safety.
            </p>
          </div>

          {/* Privacy Protocol */}
          <div
            onClick={() => onNavigate?.('rules-guides')}
            className="p-4 rounded-xl border border-neutral-200/80 dark:border-neutral-700/80 bg-neutral-50/50 dark:bg-neutral-800/40 hover:border-sky-300 dark:hover:border-sky-600 transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center mb-2.5">
              <Lock className="w-4 h-4" />
            </div>
            <h3 className="text-xs font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors flex items-center justify-between">
              <span>Privacy & Security Guidance</span>
              <ChevronRight className="w-3.5 h-3.5 text-neutral-400 group-hover:translate-x-0.5 transition-transform" />
            </h3>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 leading-relaxed">
              Guidance for device safety, client-side storage boundaries, and preventing surveillance on shared computers.
            </p>
          </div>
        </div>
      </div>

      {/* 3. Local Data & Storage Transparency */}
      <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
        <div>
          <h2 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
            Data Storage & Privacy Disclosures
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            Transparent disclosure of client-side storage mechanisms and safety boundaries.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200/80 dark:border-neutral-800 space-y-2.5 text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
          <p className="font-semibold text-neutral-900 dark:text-white flex items-center gap-1.5">
            <Lock className="w-4 h-4 text-emerald-500" />
            <span>Client-Side Technical Architecture</span>
          </p>
          <p>
            • <strong>Local Browser Storage:</strong> Private journal entries, endorsements, and interface settings exist exclusively in your browser's local memory.
          </p>
          <p>
            • <strong>No Unsubstantiated Encryption Claims:</strong> Local browser storage is convenient and avoids remote network transmission, but someone with physical administrator access to this exact device can inspect stored files.
          </p>
          <p>
            • <strong>Shared Computer Safety:</strong> If you are using a shared or public computer, always click "Purge All Data" before leaving.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <button
            onClick={handleExportAll}
            className="px-4 py-2 text-xs font-semibold rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Session Backup</span>
          </button>

          <button
            onClick={() => setShowWipeConfirm(true)}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60 flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Purge All Local Data & Reset</span>
          </button>
        </div>
      </div>

      {/* Confirmation Modal for Data Wipe */}
      {showWipeConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-neutral-900 rounded-2xl p-6 shadow-2xl border border-neutral-200 dark:border-neutral-800 animate-in zoom-in-95 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
              Purge All Local Platform Data?
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-2 leading-relaxed">
              This will erase all journal entries, votes, and preference cache from this browser. The page will reload as a pristine new session.
            </p>
            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setShowWipeConfirm(false)}
                className="flex-1 py-2 text-xs font-semibold rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowWipeConfirm(false);
                  onClearAllData();
                }}
                className="flex-1 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-700 text-white"
              >
                Confirm Purge
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
