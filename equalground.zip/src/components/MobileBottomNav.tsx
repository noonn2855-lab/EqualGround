import React from 'react';
import { Home, MessageSquare, BookHeart, PhoneCall, Shield } from 'lucide-react';
import { ViewType } from '../types';

interface MobileBottomNavProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ currentView, onNavigate }) => {
  const items: { id: ViewType; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-4 h-4" /> },
    { id: 'dashboard', label: 'Dashboard', icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'journal', label: 'Journal', icon: <BookHeart className="w-4 h-4" /> },
    { id: 'emergency', label: 'Emergency', icon: <PhoneCall className="w-4 h-4" /> },
    { id: 'settings', label: 'Profile', icon: <Shield className="w-4 h-4" /> }
  ];

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200/90 flex items-center justify-around px-2 py-1.5 safe-area-pb"
      aria-label="Mobile navigation"
    >
      {items.map((item) => {
        const isActive = currentView === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex flex-col items-center justify-center p-1.5 rounded-xl transition-all cursor-pointer min-w-[48px] ${
              isActive
                ? 'text-blue-700 font-bold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
            aria-current={isActive ? 'page' : undefined}
          >
            {item.icon}
            <span className="text-[10px] mt-0.5 tracking-tight">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
