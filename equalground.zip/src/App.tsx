import React, { useState, useEffect } from 'react';
import {
  ViewType,
  FeatureKey,
  UserProfile,
  JournalEntry,
  CommunityPost,
  ChangeProposal
} from './types';
import {
  INITIAL_GUIDES,
  INITIAL_COMMUNITY_POSTS,
  INITIAL_PROPOSALS,
  INITIAL_JOURNAL_SAMPLE
} from './data/mockData';
import { Menu } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { LoginModal } from './components/LoginModal';
import { Toast, ToastMessage } from './components/Toast';

import { LandingPage } from './components/views/LandingPage';
import { HomeView } from './components/views/HomeView';
import { FeatureIntroView } from './components/views/FeatureIntroView';
import { CommunityView } from './components/views/CommunityView';
import { RulesGuidesView } from './components/views/RulesGuidesView';
import { JournalView } from './components/views/JournalView';
import { ChangeLabView } from './components/views/ChangeLabView';
import { SettingsView } from './components/views/SettingsView';
import { EmergencyView } from './components/views/EmergencyView';

const STORAGE_KEYS = {
  USER: 'equalground_user_v1',
  AUTH: 'equalground_auth_v1',
  JOURNAL: 'equalground_journal_v1',
  COMMUNITY: 'equalground_community_v1',
  PROPOSALS: 'equalground_proposals_v1',
  SIDEBAR_COLLAPSED: 'equalground_sidebar_collapsed_v1'
};

export default function App() {
  // Authentication session state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      const savedAuth = localStorage.getItem(STORAGE_KEYS.AUTH);
      return savedAuth === 'true';
    } catch {
      return false;
    }
  });

  // User state
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USER);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return {
      id: 'guest-1',
      name: 'Guest Advocate',
      isGuest: true,
      avatarSeed: 'GA',
      joinedDate: 'Active Session'
    };
  });

  // Active View and Navigation
  const [currentView, setCurrentView] = useState<ViewType>(() => {
    return isAuthenticated ? 'home' : 'landing';
  });

  // Selected feature for intermediate explanation & instruction page
  const [selectedFeatureForIntro, setSelectedFeatureForIntro] = useState<FeatureKey>('dashboard');

  // Sidebar collapsible state
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.SIDEBAR_COLLAPSED) === 'true';
    } catch {
      return false;
    }
  });

  // Modals & Navigation state
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [loginModalTab, setLoginModalTab] = useState<'signin' | 'register'>('signin');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  // Data states with local storage
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.JOURNAL);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return INITIAL_JOURNAL_SAMPLE;
  });

  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COMMUNITY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return INITIAL_COMMUNITY_POSTS;
  });

  const [proposals, setProposals] = useState<ChangeProposal[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROPOSALS);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return INITIAL_PROPOSALS;
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Ensure unified single color theme
  useEffect(() => {
    document.documentElement.classList.remove('dark');
  }, []);

  // Online / Offline listener
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Save auth state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.AUTH, isAuthenticated ? 'true' : 'false');
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    } catch {
      // Ignore
    }
  }, [isAuthenticated, user]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SIDEBAR_COLLAPSED, isSidebarCollapsed ? 'true' : 'false');
    } catch {
      // Ignore
    }
  }, [isSidebarCollapsed]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.JOURNAL, JSON.stringify(journalEntries));
    } catch {
      // Ignore
    }
  }, [journalEntries]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.COMMUNITY, JSON.stringify(communityPosts));
    } catch {
      // Ignore
    }
  }, [communityPosts]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PROPOSALS, JSON.stringify(proposals));
    } catch {
      // Ignore
    }
  }, [proposals]);

  const addToast = (title: string, description?: string, type: 'success' | 'info' | 'warning' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newToast: ToastMessage = { id, title, description, type };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const handleLoginSuccess = (newUser: UserProfile) => {
    setUser(newUser);
    setIsAuthenticated(true);
    setCurrentView('home');
    addToast(
      newUser.isGuest ? 'Welcome Guest' : `Signed in as ${newUser.name}`,
      'Redirecting to your authenticated homepage.',
      'success'
    );
  };

  const handleSignOut = () => {
    setIsAuthenticated(false);
    setCurrentView('landing');
    addToast('Logged Out', 'You have been returned to the public landing page.', 'info');
  };

  const handleClearAllData = () => {
    try {
      localStorage.clear();
    } catch {
      // Ignore
    }
    setJournalEntries([]);
    setCommunityPosts(INITIAL_COMMUNITY_POSTS);
    setProposals(INITIAL_PROPOSALS);
    setIsAuthenticated(false);
    setUser({
      id: `guest-${Date.now()}`,
      name: 'Guest Advocate',
      isGuest: true,
      avatarSeed: 'GA',
      joinedDate: 'Active Session'
    });
    addToast('Platform Reset', 'All cached data and journal notes have been cleared.', 'info');
    setCurrentView('landing');
  };

  // Intermediate Feature Instruction Page Triggers
  const handleSelectFeatureBox = (featureKey: FeatureKey) => {
    setSelectedFeatureForIntro(featureKey);
    setCurrentView('feature-intro');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFeatureIntroContinue = (targetView: ViewType, featureKey: FeatureKey) => {
    if (featureKey === 'emergency') {
      setCurrentView('emergency');
    } else {
      setCurrentView(targetView);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Journal handlers
  const handleSaveJournalEntry = (entry: JournalEntry) => {
    setJournalEntries((prev) => {
      const index = prev.findIndex((e) => e.id === entry.id);
      if (index >= 0) {
        const updated = [...prev];
        updated[index] = entry;
        return updated;
      }
      return [entry, ...prev];
    });
  };

  const handleDeleteJournalEntry = (id: string) => {
    setJournalEntries((prev) => prev.filter((e) => e.id !== id));
    addToast('Note Deleted', 'The private note was removed from this device.', 'info');
  };

  // Community handlers
  const handleAddCommunityPost = (post: CommunityPost) => {
    setCommunityPosts((prev) => [post, ...prev]);
  };

  const handleToggleCommunitySupport = (postId: string) => {
    setCommunityPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const supported = !p.hasSupported;
          return {
            ...p,
            hasSupported: supported,
            supportCount: supported ? p.supportCount + 1 : Math.max(0, p.supportCount - 1)
          };
        }
        return p;
      })
    );
  };

  const handleAddCommunityComment = (postId: string, content: string, author: string) => {
    setCommunityPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            comments: [
              ...p.comments,
              {
                id: `c-${Date.now()}`,
                author,
                date: 'Just now',
                content
              }
            ]
          };
        }
        return p;
      })
    );
  };

  // Change Lab handlers
  const handleAddProposal = (proposal: ChangeProposal) => {
    setProposals((prev) => [proposal, ...prev]);
  };

  const handleToggleEndorseProposal = (id: string) => {
    setProposals((prev) =>
      prev.map((prop) => {
        if (prop.id === id) {
          const endorsed = !prop.hasEndorsed;
          return {
            ...prop,
            hasEndorsed: endorsed,
            endorsements: endorsed ? prop.endorsements + 1 : Math.max(0, prop.endorsements - 1)
          };
        }
        return prop;
      })
    );
    addToast('Campaign Endorsement Updated', 'Your support strengthens collective advocacy.', 'success');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* 1. Unauthenticated State: Simple, Clean Landing Page */}
      {!isAuthenticated || currentView === 'landing' ? (
        <LandingPage
          onOpenLogin={() => {
            setLoginModalTab('signin');
            setIsLoginModalOpen(true);
          }}
          onOpenSignUp={() => {
            setLoginModalTab('register');
            setIsLoginModalOpen(true);
          }}
          onContinueAsGuest={() => {
            const guestUser: UserProfile = {
              id: `guest-${Date.now()}`,
              name: 'Guest Advocate',
              isGuest: true,
              avatarSeed: 'GA',
              joinedDate: 'Active Session'
            };
            handleLoginSuccess(guestUser);
          }}
        />
      ) : (
        /* 2. Authenticated Application Workspace */
        <div className="flex flex-1 min-h-0">
          {/* Minimizable / Collapsible Sidebar */}
          <Sidebar
            currentView={currentView}
            onNavigate={(view) => {
              setCurrentView(view);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            user={user}
            isOnline={isOnline}
            isOpenMobile={isMobileMenuOpen}
            onCloseMobile={() => setIsMobileMenuOpen(false)}
            isCollapsed={isSidebarCollapsed}
            onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            onSignOut={handleSignOut}
            onOpenLogin={() => {
              setLoginModalTab('signin');
              setIsLoginModalOpen(true);
            }}
          />

          {/* Main Content Workspace */}
          <div className="flex-1 flex flex-col min-w-0 pb-16 md:pb-0 transition-all">
            {/* Mobile Header (only visible on mobile screens) */}
            <header className="md:hidden flex items-center justify-between px-4 py-3 bg-white/95 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-30">
              <button
                onClick={() => setIsMobileMenuOpen(true)}
                className="p-1.5 -ml-1 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                aria-label="Open sidebar"
              >
                <Menu className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-blue-900 via-sky-600 to-emerald-600 flex items-center justify-center text-white text-[10px] font-bold shadow-xs">
                  EG
                </div>
                <span className="font-bold text-sm text-slate-900">
                  EqualGround
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    setCurrentView('settings');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-7 h-7 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center shadow-xs cursor-pointer"
                  title={`Account: ${user.name}`}
                  aria-label="Profile and settings"
                >
                  {user.avatarSeed}
                </button>
              </div>
            </header>

            <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
              {/* Authenticated Homepage with Feature Discovery Boxes */}
              {currentView === 'home' && (
                <HomeView
                  user={user}
                  onSelectFeatureBox={handleSelectFeatureBox}
                  onNavigateToDashboard={() => {
                    setCurrentView('dashboard');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              )}

              {/* Intermediate Information & Instruction Page */}
              {currentView === 'feature-intro' && (
                <FeatureIntroView
                  featureKey={selectedFeatureForIntro}
                  onBack={() => {
                    setCurrentView('home');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onContinue={handleFeatureIntroContinue}
                />
              )}

              {/* Separate Dashboard / Community Social Feed */}
              {currentView === 'dashboard' && (
                <CommunityView
                  posts={communityPosts}
                  user={user}
                  onAddPost={handleAddCommunityPost}
                  onToggleSupport={handleToggleCommunitySupport}
                  onAddComment={handleAddCommunityComment}
                  onShowToast={addToast}
                  onNavigate={(v) => {
                    setCurrentView(v);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              )}

              {/* Profile Rules & Guides */}
              {currentView === 'rules-guides' && (
                <RulesGuidesView
                  guides={INITIAL_GUIDES}
                  onBack={() => {
                    setCurrentView('settings');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onNavigate={(v) => {
                    setCurrentView(v);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onShowToast={addToast}
                />
              )}

              {/* Private Safe Journal */}
              {currentView === 'journal' && (
                <JournalView
                  entries={journalEntries}
                  onSaveEntry={handleSaveJournalEntry}
                  onDeleteEntry={handleDeleteJournalEntry}
                  onClearAll={() => setJournalEntries([])}
                  onShowToast={addToast}
                />
              )}

              {/* Change Lab */}
              {currentView === 'changelab' && (
                <ChangeLabView
                  proposals={proposals}
                  user={user}
                  onAddProposal={handleAddProposal}
                  onToggleEndorse={handleToggleEndorseProposal}
                  onShowToast={addToast}
                />
              )}

              {/* Dedicated Location-Based Emergency Services */}
              {currentView === 'emergency' && (
                <EmergencyView
                  onShowToast={addToast}
                  onNavigate={(view) => {
                    setCurrentView(view);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onBack={() => {
                    setCurrentView('rules-guides');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              )}

              {/* Settings & Privacy (Profile) */}
              {currentView === 'settings' && (
                <SettingsView
                  user={user}
                  onOpenLogin={() => {
                    setLoginModalTab('signin');
                    setIsLoginModalOpen(true);
                  }}
                  onSignOut={handleSignOut}
                  onClearAllData={handleClearAllData}
                  onShowToast={addToast}
                  onNavigate={(view) => {
                    setCurrentView(view);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              )}
            </main>
          </div>
        </div>
      )}

      {/* Mobile Bottom Navigation (only when authenticated) */}
      {isAuthenticated && currentView !== 'landing' && (
        <MobileBottomNav
          currentView={currentView}
          onNavigate={(view) => {
            setCurrentView(view);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      )}

      {/* Login & Registration Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        initialTab={loginModalTab}
        onClose={() => setIsLoginModalOpen(false)}
        onSuccess={handleLoginSuccess}
      />

      {/* Toast Feedback */}
      <Toast toasts={toasts} onDismiss={handleDismissToast} />
    </div>
  );
}
