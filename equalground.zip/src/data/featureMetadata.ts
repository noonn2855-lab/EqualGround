import { FeatureKey, FeatureMetadata } from '../types';

export const FEATURES_METADATA: Record<FeatureKey, FeatureMetadata> = {
  dashboard: {
    key: 'dashboard',
    title: 'Community Dashboard',
    shortDescription: 'A supportive, social-media-style feed to share lived experiences, seek solidarity, and discuss justice initiatives.',
    iconName: 'MessageSquare',
    accentColor: 'emerald',
    whatItDoes: 'The Community Dashboard is a peer-to-peer social feed where survivors, allies, and advocates connect. You can choose to post with your profile or post completely anonymously as "Anonymous Member", read courageous stories, react with Care, and offer encouraging replies in a respectful environment.',
    instructions: [
      'Scroll through the community feed to read posts organized by stories, questions, and solidarity.',
      'Choose between "Post with my profile" and "Post anonymously" when drafting any new entry.',
      'Use the "Care" button to show empathy and solidarity.',
      'Open replies to offer supportive comments or practical guidance.'
    ],
    targetView: 'dashboard'
  },
  journal: {
    key: 'journal',
    title: 'Private Safe Journal',
    shortDescription: 'A completely confidential, device-local notebook for incident logs, evidence notes, and personal healing reflections.',
    iconName: 'BookHeart',
    accentColor: 'sky',
    whatItDoes: 'The Private Journal acts as a client-side safe vault. Any notes, dates, witness accounts, or emotional reflections you write are stored exclusively in your browser\'s local storage. No network telemetry or remote servers ever receive this data.',
    instructions: [
      'Click "New Entry" to create a confidential note with category tags and private text.',
      'Record specific dates, locations, words spoken, or evidence details while fresh in memory.',
      'Export your notes at any time to a clean JSON file for personal offline storage.',
      'Use the "Quick Wipe" feature to instantly erase all entries from this browser if immediate privacy is required.'
    ],
    targetView: 'journal'
  },
  changelab: {
    key: 'changelab',
    title: 'Change Lab & Reform',
    shortDescription: 'Civic action platform where grassroots voices propose policy changes, launch petitions, and mobilize for systemic reform.',
    iconName: 'Megaphone',
    accentColor: 'blue',
    whatItDoes: 'Change Lab channels lived struggles into actionable policy reform. Review community-drafted proposals targeting corporate boards, ministries of justice, and human rights bodies, or submit your own reform campaign for community endorsement.',
    instructions: [
      'Review active reform proposals and monitor their status (Proposed, Under Review, Active Campaign).',
      'Click "Endorse" to add your voice and increase a campaign\'s visibility and impact.',
      'Click "Propose Reform" to draft a new legislative proposal detailing the issue, solution, and target authority.',
      'Track community-backed initiatives as they progress toward institutional review.'
    ],
    targetView: 'changelab'
  },
  emergency: {
    key: 'emergency',
    title: 'Location Emergency Contacts',
    shortDescription: 'Verified emergency numbers for police, medical, fire rescue, and crisis helplines according to your selected location.',
    iconName: 'PhoneCall',
    accentColor: 'rose',
    whatItDoes: 'Direct access to verified national and regional emergency services (police, ambulance, fire, and specialized crisis hotlines) based on your selected country, with clear dialing advice and one-click copy.',
    instructions: [
      'Select your country or region from the verified location directory.',
      'View primary emergency numbers and detailed services for police, medical, and fire rescue.',
      'Copy verified numbers with one click or read local dialing instructions.',
      'If your country is unlisted, follow standard GSM guidance (112 / 911) and verify with local operators.'
    ],
    targetView: 'emergency'
  },
  settings: {
    key: 'settings',
    title: 'Privacy & Interface Settings',
    shortDescription: 'Switch appearance modes (Light/Dark), review honest storage disclosures, and manage local data retention.',
    iconName: 'Shield',
    accentColor: 'slate' as any,
    whatItDoes: 'Manage your visual comfort and local storage retention. Toggle between Light Mode and Dark Mode, read transparent local storage security disclosures, and perform full session purges.',
    instructions: [
      'Toggle between Light and Dark visual modes on any page across the entire application.',
      'Review honest privacy disclosures explaining client-side storage boundaries.',
      'Export session backups to your personal drive.',
      'Purge all browser-stored data with a single click before closing shared or public computers.'
    ],
    targetView: 'settings'
  }
};
