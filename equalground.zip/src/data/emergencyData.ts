import { CountryEmergencyData } from '../types';

export const COUNTRIES_EMERGENCY_DATA: CountryEmergencyData[] = [
  {
    countryCode: 'US',
    countryName: 'United States',
    flag: '🇺🇸',
    primaryNumber: '911',
    services: [
      { service: 'General Emergency (Police, Fire, Medical)', number: '911', type: 'general', description: 'Immediate nationwide dispatch for police, fire, or ambulance' },
      { service: 'National Crisis & Suicide Lifeline', number: '988', type: 'helpline', description: '24/7 free and confidential mental health and crisis support' },
      { service: 'National Sexual Assault Hotline (RAINN)', number: '1-800-656-4673', type: 'helpline', description: '24/7 confidential survivor advocacy and crisis counseling' },
      { service: 'National Domestic Violence Hotline', number: '1-800-799-7233', type: 'helpline', description: '24/7 support or text START to 88788' }
    ],
    dialingNotes: 'Dial 911 from any active mobile phone or landline even without a SIM or active calling plan.'
  },
  {
    countryCode: 'GB',
    countryName: 'United Kingdom',
    flag: '🇬🇧',
    primaryNumber: '999',
    services: [
      { service: 'Emergency (Police, Ambulance, Fire, Coastguard)', number: '999', type: 'general', description: 'National emergency services dispatch' },
      { service: 'European Emergency Number', number: '112', type: 'general', description: 'Free emergency number that routes identically to 999' },
      { service: 'Non-Emergency Police', number: '101', type: 'police', description: 'For reporting non-immediate crimes or incidents' },
      { service: 'NHS Medical Advice', number: '111', type: 'medical', description: 'For urgent medical queries that are not life-threatening' },
      { service: 'National Domestic Abuse Helpline', number: '0808 2000 247', type: 'helpline', description: '24/7 freephone operated by Refuge' }
    ],
    dialingNotes: 'Both 999 and 112 operate free of charge across all UK networks.'
  },
  {
    countryCode: 'EU',
    countryName: 'European Union (All Member States)',
    flag: '🇪🇺',
    primaryNumber: '112',
    services: [
      { service: 'Single European Emergency Call', number: '112', type: 'general', description: 'Reaches police, medical, and fire rescue across all 27 EU nations' },
      { service: 'Missing Children Hotline', number: '116 000', type: 'helpline', description: 'Free pan-European hotline for missing children' },
      { service: 'Victims of Crime Support', number: '116 006', type: 'helpline', description: 'Pan-European helpline for emotional and legal guidance' }
    ],
    dialingNotes: '112 can be dialed free of charge from any fixed or mobile phone in all 27 EU countries.'
  },
  {
    countryCode: 'CA',
    countryName: 'Canada',
    flag: '🇨🇦',
    primaryNumber: '911',
    services: [
      { service: 'General Emergency (Police, Fire, Medical)', number: '911', type: 'general', description: 'Nationwide dispatch for immediate life-safety emergencies' },
      { service: 'Suicide Crisis Helpline', number: '988', type: 'helpline', description: '24/7 toll-free call and text crisis line across Canada' },
      { service: 'Kids Help Phone', number: '1-800-668-6868', type: 'helpline', description: '24/7 free counseling for youth, or text CONNECT to 686868' }
    ],
    dialingNotes: 'Available in English and French. TTY services accessible via 711.'
  },
  {
    countryCode: 'AU',
    countryName: 'Australia',
    flag: '🇦🇺',
    primaryNumber: '000',
    services: [
      { service: 'Triple Zero (Police, Fire, Ambulance)', number: '000', type: 'general', description: 'National primary emergency contact' },
      { service: 'Mobile Emergency Alternative', number: '112', type: 'general', description: 'GSM mobile standard that connects directly to Triple Zero' },
      { service: 'State Emergency Service (SES Flood/Storm)', number: '132 500', type: 'general', description: 'Assistance during natural disasters and floods' },
      { service: '1800RESPECT (Domestic & Sexual Violence)', number: '1800 737 732', type: 'helpline', description: '24/7 national confidential support line' }
    ],
    dialingNotes: 'Triple Zero (000) is always free from any mobile phone, payphone, or landline.'
  },
  {
    countryCode: 'DE',
    countryName: 'Germany',
    flag: '🇩🇪',
    primaryNumber: '112',
    services: [
      { service: 'Fire & Medical Emergency (Feuerwehr / Notarzt)', number: '112', type: 'medical', description: 'Immediate response for fire rescue and ambulance' },
      { service: 'Police (Polizei)', number: '110', type: 'police', description: 'Direct police dispatch for criminal offenses or danger' },
      { service: 'Violence Against Women Helpline', number: '116 016', type: 'helpline', description: 'Free, multilingual 24/7 advice across Germany' }
    ],
    dialingNotes: '112 and 110 are completely free from any phone without dialing an area code.'
  },
  {
    countryCode: 'FR',
    countryName: 'France',
    flag: '🇫🇷',
    primaryNumber: '112',
    services: [
      { service: 'European Emergency (General)', number: '112', type: 'general', description: 'Universal emergency line across France' },
      { service: 'Emergency Medical Service (SAMU)', number: '15', type: 'medical', description: 'Direct medical team dispatch for severe emergencies' },
      { service: 'Police Nationale / Gendarmerie', number: '17', type: 'police', description: 'Police intervention' },
      { service: 'Fire Brigade (Sapeurs-Pompiers)', number: '18', type: 'fire', description: 'Fire and accident rescue' },
      { service: 'Women Victims of Violence', number: '3919', type: 'helpline', description: 'Free and anonymous national helpline' }
    ],
    dialingNotes: 'All emergency numbers (15, 17, 18, 112) can be reached toll-free.'
  },
  {
    countryCode: 'IN',
    countryName: 'India',
    flag: '🇮🇳',
    primaryNumber: '112',
    services: [
      { service: 'National Emergency Number (ERSS)', number: '112', type: 'general', description: 'Unified pan-India emergency response number' },
      { service: 'Police Control Room', number: '100', type: 'police', description: 'Direct police assistance' },
      { service: 'Ambulance & Medical Emergency', number: '102 / 108', type: 'medical', description: 'Government ambulance service' },
      { service: 'Fire Service', number: '101', type: 'fire', description: 'Fire rescue service' },
      { service: 'Women Helpline', number: '1091', type: 'helpline', description: '24/7 assistance for women facing distress or harassment' }
    ],
    dialingNotes: '112 integrates police (100), fire (101), ambulance (102/108), and disaster lines into a unified system.'
  },
  {
    countryCode: 'JP',
    countryName: 'Japan',
    flag: '🇯🇵',
    primaryNumber: '110 / 119',
    services: [
      { service: 'Police (Keisatsu)', number: '110', type: 'police', description: 'Reporting crime, assault, or traffic accidents' },
      { service: 'Fire & Ambulance (Shoubou / Kyuukyuu)', number: '119', type: 'medical', description: 'Emergency medical aid and fire rescue' },
      { service: 'Japan Coast Guard (Kaijo Hoancho)', number: '118', type: 'general', description: 'Maritime distress and accidents' },
      { service: 'Sexual Violence Survivor Helpline (One-Stop)', number: '#8891', type: 'helpline', description: 'Connects to local certified counseling center' }
    ],
    dialingNotes: 'When calling 119, clearly state whether it is a fire (kaji) or ambulance (kyuukyuu).'
  },
  {
    countryCode: 'MM',
    countryName: 'Myanmar',
    flag: '🇲🇲',
    primaryNumber: '199',
    services: [
      { service: 'Police Department', number: '199', type: 'police', description: 'General emergency police services' },
      { service: 'Ambulance & Red Cross', number: '192', type: 'medical', description: 'Emergency hospital and medical ambulance services' },
      { service: 'Fire Brigade Rescue', number: '191', type: 'fire', description: 'Fire rescue and emergency disaster response' }
    ],
    dialingNotes: 'Please confirm local community and municipal contacts if public phone infrastructure is delayed.'
  },
  {
    countryCode: 'BR',
    countryName: 'Brazil',
    flag: '🇧🇷',
    primaryNumber: '190',
    services: [
      { service: 'Military Police (Polícia Militar)', number: '190', type: 'police', description: 'Immediate public security and police assistance' },
      { service: 'Emergency Ambulance (SAMU)', number: '192', type: 'medical', description: 'Urgent mobile medical assistance' },
      { service: 'Fire Department (Corpo de Bombeiros)', number: '193', type: 'fire', description: 'Rescue, search, and fire containment' },
      { service: 'Central de Atendimento à Mulher', number: '180', type: 'helpline', description: 'National women protection and human rights line' }
    ],
    dialingNotes: 'Numbers are toll-free from any telephone across all Brazilian states.'
  },
  {
    countryCode: 'ZA',
    countryName: 'South Africa',
    flag: '🇿🇦',
    primaryNumber: '10111 / 112',
    services: [
      { service: 'Police Flying Squad', number: '10111', type: 'police', description: 'South African Police Service (SAPS) national line' },
      { service: 'Ambulance & Fire Services', number: '10177', type: 'medical', description: 'Emergency medical rescue and fire response' },
      { service: 'Cell Phone Emergency Call', number: '112', type: 'general', description: 'Free emergency call from any mobile phone' },
      { service: 'Gender-Based Violence Command Centre', number: '0800 428 428', type: 'helpline', description: '24/7 toll-free survivor support' }
    ],
    dialingNotes: 'Dialing 112 from a mobile phone connects to an automated routing center.'
  },
  {
    countryCode: 'KR',
    countryName: 'South Korea',
    flag: '🇰🇷',
    primaryNumber: '112 / 119',
    services: [
      { service: 'Police Emergency', number: '112', type: 'police', description: 'National police emergency report center' },
      { service: 'Fire & Emergency Medical', number: '119', type: 'medical', description: 'Fire rescue and ambulance dispatch' },
      { service: 'Women Crisis Hotline', number: '1366', type: 'helpline', description: '24/7 crisis support and emergency shelter coordination' }
    ],
    dialingNotes: 'Interpretation services available for foreign callers.'
  },
  {
    countryCode: 'SG',
    countryName: 'Singapore',
    flag: '🇸🇬',
    primaryNumber: '999',
    services: [
      { service: 'Police', number: '999', type: 'police', description: 'Immediate police response' },
      { service: 'Civil Defence Force (Ambulance & Fire)', number: '995', type: 'medical', description: 'Emergency ambulance and fire rescue' },
      { service: 'Non-Emergency Ambulance', number: '1777', type: 'medical', description: 'For non-critical medical transport' }
    ],
    dialingNotes: 'Dial 999 for police, 995 for emergency ambulance/fire.'
  },
  {
    countryCode: 'NZ',
    countryName: 'New Zealand',
    flag: '🇳🇿',
    primaryNumber: '111',
    services: [
      { service: 'Emergency (Police, Fire, Ambulance)', number: '111', type: 'general', description: 'National primary emergency contact' },
      { service: 'Non-Emergency Police', number: '105', type: 'police', description: 'For non-urgent crime reporting' }
    ],
    dialingNotes: '111 works on all networks even without SIM or phone credit.'
  },
  {
    countryCode: 'MX',
    countryName: 'Mexico',
    flag: '🇲🇽',
    primaryNumber: '911',
    services: [
      { service: 'National Emergency Line', number: '911', type: 'general', description: 'Integrated police, medical, and fire dispatch' },
      { service: 'Anonymous Crime Tip Line', number: '089', type: 'police', description: 'Confidential reporting without personal identification' }
    ],
    dialingNotes: 'Operates nationwide throughout all 32 federal entities.'
  }
];

export const DEFAULT_COUNTRY_CODE = 'US';
