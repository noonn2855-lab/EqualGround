import { RightsGuide, CommunityPost, ChangeProposal, CrisisContact, JournalEntry } from '../types';

export const INITIAL_GUIDES: RightsGuide[] = [
  {
    id: 'guide-violence',
    title: 'Immediate Safety & Protection Following Sexual Violence',
    category: 'violence',
    summary: 'Clear, confidential medical, psychological, and legal options available regardless of nationality or background.',
    fullContent: [
      'Your immediate physical safety and medical care take absolute priority over any legal paperwork.',
      'Emergency health services (preventive prophylaxis, injury care, forensic preservation if chosen) should be sought within 72 hours where possible.',
      'You maintain full autonomy over whether, when, and how you report to statutory authorities. No survivor should be forced to pursue criminal charges without informed consent.',
      'Document whatever details you can comfortably recall in a safe, encrypted space without exposing yourself to retributive risks.'
    ],
    actionSteps: [
      'Seek a safe location away from the perpetrator immediately.',
      'Contact a confidential advocate or crisis helpline before speaking to general personnel.',
      'Preserve any digital messages, recordings, clothing, or witness notes safely.',
      'Request free or subsidized trauma-informed psychosocial counseling.'
    ],
    legalBasis: 'UN Declaration of Basic Principles of Justice for Victims of Crime & Abuse of Power; CEDAW General Recommendation No. 35.',
    resources: [
      { name: 'International Sexual Assault Hotline Directory', contact: '1-800-656-4673 / online.rainn.org', isHotline: true },
      { name: 'Global Crisis Text Service', contact: 'Text SUPPORT to 741741', isHotline: true },
      { name: 'Independent Survivor Advocates Network', contact: 'support@equalground-advocacy.org' }
    ],
    accentColor: 'red'
  },
  {
    id: 'guide-discrimination',
    title: 'Combating Racial Discrimination & Systemic Bias',
    category: 'racial',
    summary: 'Recognizing overt and subtle racial discrimination in employment, public services, housing, and social spaces.',
    fullContent: [
      'No person may be denied equal access, fair compensation, or dignity on grounds of ethnic heritage, skin color, ancestry, or national origin.',
      'Workplace discrimination often masks itself as "cultural mismatch" or subjective grading; objective metric comparison is standard evidence.',
      'You are protected against retaliation when reporting racial misconduct or filing a formal inquiry with equality commissions.'
    ],
    actionSteps: [
      'Maintain an objective timeline recording dates, witnesses, explicit remarks, and policy discrepancies.',
      'Request written reasons for denied promotions, housing rejections, or disciplinary actions.',
      'Liaise with non-profit civil rights organizations for collective legal backing.'
    ],
    legalBasis: 'International Convention on the Elimination of All Forms of Racial Discrimination (ICERD) & Article 2 UDHR.',
    resources: [
      { name: 'Racial Justice Legal Coalition', contact: 'contact@racialjustice-global.org' },
      { name: 'Universal Equal Rights Ombudsman Office', contact: '1-888-245-8890', isHotline: true }
    ],
    accentColor: 'blue'
  },
  {
    id: 'guide-gender',
    title: 'Gender Equality & Freedom from Institutional Harassment',
    category: 'gender',
    summary: 'Defending equality across all genders, dismantling pay gaps, and addressing systemic harassment.',
    fullContent: [
      'Gender equality guarantees equal compensation for equal work, non-discriminatory promotions, and freedom from coercive gender expectations.',
      'Sexual harassment encompasses unwelcome physical contact, verbal coercion, quid pro quo demands, or hostile work environments.',
      'Both formal employees and informal/contract workers possess inherent human rights to bodily integrity and safe environments.'
    ],
    actionSteps: [
      'Review your organization’s anti-harassment policy and identify designated safety contacts.',
      'Communicate clear refusal in writing where safe to do so to establish lack of consent.',
      'Consult with trusted gender rights advocacy groups for strategic guidance.'
    ],
    legalBasis: 'Convention on the Elimination of All Forms of Discrimination Against Women (CEDAW) & ILO Convention No. 190.',
    resources: [
      { name: 'Women & Gender Rights Defense Project', contact: 'help@genderdefense.org' },
      { name: 'Confidential Workplace Harassment Bureau', contact: '1-800-555-4363', isHotline: true }
    ],
    accentColor: 'sky'
  },
  {
    id: 'guide-tradition',
    title: 'Challenging Harmful Traditions & Coercive Practices',
    category: 'tradition',
    summary: 'When traditional customs violate bodily autonomy, force marriages, or deny education, human rights supersede tradition.',
    fullContent: [
      'Cultural heritage is a rich human treasure, but traditions cannot be weaponized to justify physical mutilation, forced marriage, or denial of basic schooling.',
      'International human rights law firmly establishes that individual consent and bodily integrity override patriarchal or clan mandates.',
      'Youth and women facing coercive family pressure are entitled to protection, emergency sanctuary, and confidential legal intervention.'
    ],
    actionSteps: [
      'Recognize that forced isolation, physical threats, or passport confiscation are criminal acts.',
      'Identify trusted neutral allies or international non-governmental shelters before an impending forced event.',
      'Seek emergency restraining orders or protective custody through child/civil rights services.'
    ],
    legalBasis: 'UDHR Article 16 (Free and full consent to marriage) & UN Resolution on Child, Early, and Forced Marriage.',
    resources: [
      { name: 'Global Freedom from Coercion Hotline', contact: '1-888-373-7888', isHotline: true },
      { name: 'Safe Haven Cultural Mediation Network', contact: 'safe@freedomfromcoercion.org' }
    ],
    accentColor: 'emerald'
  },
  {
    id: 'guide-labor',
    title: 'Workplace Rights, Fair Wages & Freedom from Exploitation',
    category: 'labor',
    summary: 'Guaranteed protections against wage theft, unsafe working conditions, and retaliation against organizing.',
    fullContent: [
      'Every worker has the right to just and favorable conditions of work, including fair wages and rest.',
      'Employers cannot confiscate identification documents or coerce workers through visa threats.',
      'Whistleblower protections shield employees who expose safety hazards, financial fraud, or human rights violations.'
    ],
    actionSteps: [
      'Retain independent copies of contracts, pay slips, and logged working hours.',
      'Report safety violations directly to statutory labor inspectorates.',
      'Join or form an independent worker committee for collective bargaining.'
    ],
    legalBasis: 'ILO Fundamental Conventions on Freedom of Association & Forced Labour.',
    resources: [
      { name: 'Fair Work Legal Advocacy Project', contact: 'labor@fairwork-defense.org' },
      { name: 'Worker Exploitation Confidential Line', contact: '1-800-444-5226', isHotline: true }
    ],
    accentColor: 'blue'
  }
];

export const INITIAL_COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: 'post-1',
    title: 'Speaking out against forced family customs changed my path',
    author: 'ResilientSky',
    isAnonymous: false,
    category: 'Shared Story',
    date: '4 hours ago',
    content: 'For years I was told that questioning traditional early marriage was dishonoring my community. Discovering that international human rights and domestic statutes protected my autonomy gave me the courage to seek academic mediation. I am now finishing my degree in public health.',
    hasTriggerWarning: false,
    supportCount: 42,
    comments: [
      {
        id: 'c-1',
        author: 'CourageWalker',
        date: '3 hours ago',
        content: 'Your courage opens doors for thousands of others. Respecting heritage shouldn\'t mean surrendering our freedom to learn.'
      },
      {
        id: 'c-2',
        author: 'AdvocateNora',
        date: '1 hour ago',
        content: 'Thank you for reminding us that tradition must evolve to honor every human life.'
      }
    ]
  },
  {
    id: 'post-2',
    title: 'How to document micro-aggressions and racial bias without risking your job',
    author: 'DignityFirst',
    isAnonymous: false,
    category: 'Legal Question',
    date: 'Yesterday',
    content: 'When facing subtle bias in team performance evaluations, don’t rely on memory. Keep a personal notebook outside workplace servers. Record exact dates, verbatim comments, witness presence, and work output metrics. Has anyone here utilized this evidence successfully in mediation?',
    hasTriggerWarning: false,
    supportCount: 29,
    comments: [
      {
        id: 'c-3',
        author: 'LegalBeacon',
        date: '18 hours ago',
        content: 'Yes! Contemporaneous notes (written within 24 hours of each occurrence) carry tremendous evidentiary weight in labor tribunals.'
      }
    ]
  },
  {
    id: 'post-3',
    title: 'Reminder: Healing is non-linear, and your voice matters here',
    author: 'Anonymous Member',
    isAnonymous: true,
    category: 'Solidarity',
    date: '2 days ago',
    content: 'To anyone navigating the heavy aftermath of gender-based violence or unfair dismissal: take your time. You are not required to be a warrior every single day. Taking a quiet breath and knowing you are safe today is already an act of courage.',
    hasTriggerWarning: false,
    supportCount: 68,
    comments: []
  }
];


export const INITIAL_PROPOSALS: ChangeProposal[] = [
  {
    id: 'prop-1',
    title: 'Mandatory Independent Oversight for Workplace Harassment Grievances',
    summary: 'Require mid-to-large institutions to utilize accredited independent third-party investigators rather than internal HR to prevent bias and conflict of interest.',
    category: 'Institutional Reform',
    author: 'AdvocateCouncil',
    endorsements: 184,
    status: 'Active Campaign',
    targetAudience: 'Labor ministries & corporate boards',
    date: 'Oct 2026'
  },
  {
    id: 'prop-2',
    title: 'Protection of Bodily Autonomy Over Harmful Clan & Traditional Enforcement',
    summary: 'Codify statutory penalties against forced marital consent and cultural coercion, establishing emergency safe houses with direct judicial backing.',
    category: 'Human Rights Statute',
    author: 'FreedomVoice',
    endorsements: 237,
    status: 'Under Review',
    targetAudience: 'Parliamentary Human Rights Committees',
    date: 'Sep 2026'
  },
  {
    id: 'prop-3',
    title: 'Free Legal Aid Voucher System for Low-Income Victims of Discrimination',
    summary: 'Ensure no individual is denied justice due to court filing fees or inability to retain legal counsel when challenging unlawful termination or civil rights infringements.',
    category: 'Access to Justice',
    author: 'EquityCivics',
    endorsements: 312,
    status: 'Active Campaign',
    targetAudience: 'Judicial Administrations & Bar Associations',
    date: 'Aug 2026'
  }
];

export const CRISIS_CONTACTS: CrisisContact[] = [
  {
    title: 'Immediate Physical Emergency',
    service: 'Local Emergency Services',
    number: 'Call 911 / 112 / 999',
    type: 'emergency',
    availability: '24/7 Immediate Response'
  },
  {
    title: 'Confidential Sexual Assault Support',
    service: 'Global Survivor Helpline',
    number: '+1 (800) 656-4673',
    type: 'counseling',
    availability: '24/7 Toll-Free & Anonymous'
  },
  {
    title: 'Civil Rights & Discrimination Helpline',
    service: 'Equal Rights Legal Collective',
    number: '+1 (888) 245-8890',
    type: 'legal',
    availability: 'Mon-Fri 08:00 - 20:00 UTC'
  },
  {
    title: 'Crisis Text & Safe Counseling',
    service: 'Crisis Text Lifeline',
    number: 'Text HELLO to 741741',
    type: 'counseling',
    availability: '24/7 Free & Confidential'
  }
];

export const INITIAL_JOURNAL_SAMPLE: JournalEntry[] = [
  {
    id: 'entry-welcome',
    title: 'Welcome to your Private Safe Vault',
    category: 'Hope & Healing',
    date: 'Today',
    content: 'This journal is your completely private, unmonitored space on this device. Everything you write here remains in your browser storage only. No external telemetry, no remote databases. Use it to record daily thoughts, organize evidence, or reflect on your journey toward equality and peace.',
    isConfidential: true,
    tags: ['SafeSpace', 'FirstEntry', 'PrivacyFirst']
  }
];
