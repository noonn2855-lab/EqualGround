export type ViewType =
  | 'landing'
  | 'home'
  | 'dashboard'
  | 'feature-intro'
  | 'journal'
  | 'changelab'
  | 'settings'
  | 'emergency'
  | 'rules-guides';

export type FeatureKey =
  | 'dashboard'
  | 'journal'
  | 'changelab'
  | 'settings'
  | 'emergency';

export type ThemeMode = 'light' | 'dark';

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  isGuest: boolean;
  avatarSeed: string;
  joinedDate: string;
}

export interface FeatureMetadata {
  key: FeatureKey;
  title: string;
  shortDescription: string;
  iconName: string;
  accentColor: 'blue' | 'emerald' | 'sky' | 'rose' | 'amber';
  whatItDoes: string;
  instructions: string[];
  targetView: ViewType;
}

export interface RightsGuide {
  id: string;
  title: string;
  category: 'gender' | 'racial' | 'violence' | 'tradition' | 'labor' | 'general';
  summary: string;
  fullContent: string[];
  actionSteps: string[];
  legalBasis: string;
  resources: { name: string; contact: string; isHotline?: boolean }[];
  accentColor: 'red' | 'blue' | 'sky' | 'emerald';
}

export interface PlatformRule {
  id: string;
  title: string;
  category: 'community' | 'privacy';
  summary: string;
  principles: string[];
  guidance: string;
}

export interface JournalEntry {
  id: string;
  title: string;
  category: 'Reflection' | 'Incident Log' | 'Legal Note' | 'Hope & Healing';
  date: string;
  content: string;
  isConfidential: boolean;
  tags: string[];
}

export interface CommunityComment {
  id: string;
  author: string;
  date: string;
  content: string;
}

export interface CommunityPost {
  id: string;
  title: string;
  author: string;
  isAnonymous: boolean;
  category: 'Shared Story' | 'Legal Question' | 'Reform Idea' | 'Solidarity';
  date: string;
  content: string;
  hasTriggerWarning: boolean;
  supportCount: number;
  hasSupported?: boolean;
  comments: CommunityComment[];
}

export interface ChangeProposal {
  id: string;
  title: string;
  summary: string;
  category: string;
  author: string;
  endorsements: number;
  hasEndorsed?: boolean;
  status: 'Proposed' | 'Under Review' | 'Active Campaign';
  targetAudience: string;
  date: string;
}

export interface EmergencyServiceItem {
  service: string;
  number: string;
  description?: string;
  type: 'police' | 'medical' | 'fire' | 'general' | 'helpline';
}

export interface CountryEmergencyData {
  countryCode: string;
  countryName: string;
  flag: string;
  primaryNumber: string;
  services: EmergencyServiceItem[];
  dialingNotes?: string;
}

export interface CrisisContact {
  title: string;
  service: string;
  number: string;
  type: 'emergency' | 'counseling' | 'legal';
  availability: string;
}
